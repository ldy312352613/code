const express=require('express');
//引入查询字符串模块
const querystring=require('querystring');
//创建web服务器
var server=express();
//设置端口8080
server.listen(8080);
//路由
server.get('/reg',function(req,res){
  res.sendFile(__dirname+'/reg.html');
});
//根据表单的请求添加对应的路由
//post  /myreg
server.post('/myreg',function(req,res){
  //获取post请求传递的数据
  //以事件的形式
  //当有数据传输自动触发事件
  //使用回调函数接收数据 
  req.on('data',function(buf){
    //buf 传递的数据,是buffer形式
	//console.log(buf.toString());
	//查询字符串
	var str=buf.toString();
	//查询字符串(querystring)格式化为对象
	var obj=querystring.parse(str);
	console.log(obj);
  });

  res.send('注册成功');
});
// get  /login   login.html
server.get('/login',function(req,res){
  res.sendFile(__dirname+'/login.html');
});
//根据表单的请求创建对应的路由
//get /mylogin
server.get('/mylogin',function(req,res){
  //获取get请求传递数据
  console.log(req.query);
  res.send('登录成功');
});
//路由传参 
server.get('/detail/:lid',function(req,res){
  //接收路由传递的数据
  console.log(req.params);
  res.send('商品详情');
});
//购物车路由
server.get('/shopping/:pname/:price',function(req,res){
  console.log(req.params);
  res.send('这是购物车');
});



const express=require('express');
//创建路由器
//对象
var router=express.Router();
//添加路由
router.get('/list',function(req,res){
  res.send('这是用户模块下的列表');
});

//导出路由器
module.exports=router;

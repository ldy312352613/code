//引入express
const express=require('express');
//创建web服务器
var server=express();
//设置端口
server.listen(8080);

//路由
//get：请求的方法
//参数1: 请求的URL
//参数2: 响应
server.get('/index',function(req,res){
  //req: 请求的对象
  //res: 响应的对象
  res.send('这是首页');
});
//练习：创建路由,请求方法为get，请求的URL：/login，响应 '请登录'
server.get('/login',function(req,res){
  //send调用一次，就代表响应结束；就不允许再次响应。
  res.send(`
	请登录<br>
	欢迎
  `);
  //res.send('欢迎');
});
//练习：创建路由，请求方法get，请求url: /list ，响应内容 '这是商品列表'
server.get('/list',function(req,res){
  //res.send('这是商品列表');
  //响应list.html文件到浏览器
  res.sendFile(__dirname+'/list.html');
});
//console.log(__dirname);
//请求方法：get，请求URL：/study，响应中跳转到 http://www.tmooc.cn
server.get('/study',function(req,res){
  //跳转
  res.redirect('http://www.tmooc.cn');
});





const http=require('http');
//创建web服务器
var server=http.createServer();
//设置端口
server.listen(8080);
//接收浏览器的请求
server.on('request',function(req,res){
  //console.log(req.method,req.url);
  //console.log(req.headers);
  //res.write('hello world');
  //res.end();
  //根据不同的请求的url做出响应
  if(req.url=='/login'){
    res.write('this is login page');
  }else if(req.url=='/member'){
    res.write('welcome to home');
  }else if(req.url=='/'){
    //重定向
	res.writeHead(302,{
	  Location:'/login'
	});
  }else{
    //其它的情况
	res.writeHead(404,{});
	res.write('404 not found');
  }
  //结束并发送响应
  res.end();
})


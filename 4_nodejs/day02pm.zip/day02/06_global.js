//开启一次性定时器
/*
var timer=global.setTimeout(function(){
  console.log('炸弹爆炸');
},3000);
//清除一次性定时器
global.clearTimeout(timer);

//周期性定时器
var timer=setInterval(()=>{
  console.log('滴滴滴滴');
},3000);
clearInterval(timer);

//练习：使用周期性定时器每隔3秒钟打印hello，打印三次以后，清除定时器
var i=0;
var timer=setInterval(function(){
  console.log('hello');
  //次数加1
  i++;
  //当i为3的时候，清除定时器
  if(i==3){
    clearInterval(timer);
  }
},3000);
*/
//立即执行定时器
var timer=setImmediate(function(){
  //回调函数会放入到队列中
  //当主线程执行完，才会执行队列的内容
  //console.log(1);
  console.log('查询数据-1');
});
//clearImmediate(timer);
//在主程序执行完，立即执行
process.nextTick(function(){
  console.log('操作数据-2');
});

//连接数据库
console.log('连接数据库');









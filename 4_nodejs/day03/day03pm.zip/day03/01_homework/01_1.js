const querystring=require('querystring');
const obj=require('02_2');
console.log(obj.qs);
var obj2=querystring.parse( obj.qs );
console.log(obj2);
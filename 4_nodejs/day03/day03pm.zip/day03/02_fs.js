//引入fs模块
const fs=require('fs');
/*
//异步方法
fs.stat('01_homework',function(err,stats){
  if(err) throw err;
  console.log(stats);
})

//把查看的文件状态保存到了变量中
//使用方法的返回值获取结果
//同步方法
var stats=fs.statSync('01_homework');
console.log(stats);

//2.创建目录
fs.mkdir('mydir2',function(err){
  if(err) throw err;
  //其它的后续操作
  console.log('目录创建成功');
});
fs.mkdirSync('mydir3');

//3.移除目录
fs.rmdir('mydir3',function(err){
  if(err) throw err;
  console.log('移除成功');
});

fs.rmdirSync('mydir2');

//4.读取目录中的内容
fs.readdir('01_homework',function(err,files){
  if(err) throw err;
  //files是读取的结果
  console.log(files);
});

var files=fs.readdirSync('01_homework');
console.log(files);

//5.创建(写入)文件
//清空写入
fs.writeFile('1.txt','tedu',function(err){
  if(err) throw err;
  console.log('写入文件');
});

//6.追加写入
fs.appendFile('2.txt','tedu\n',function(err){
  if(err) throw err;
  console.log('写入文件');
});

var arr=['tom','jerry','king'];
//遍历数组，获取每个元素
for(var i=0;i<arr.length;i++){
  //arr[i]
  //把每个元素写入到文件中
  fs.appendFileSync('data.txt',arr[i]+'\n');
}

//7.读取文件
fs.readFile('1.txt',function(err,data){
  if(err) throw err;
  console.log(data.toString());
});

//8.删除文件
fs.unlink('1.txt',function(err){
  if(err) throw err;
});

//9.判断文件是否存在
var res=fs.existsSync('mydir2');
console.log(res);
*/
//练习：判断文件2.txt是否存在，如果存在删除。
if( fs.existsSync('2.txt') ){
  fs.unlinkSync('2.txt');
}
//判断目录mydir2是否存在，如果不存在创建
if( !fs.existsSync('mydir2') ){
  fs.mkdirSync('mydir2');
}


//console.log(1);





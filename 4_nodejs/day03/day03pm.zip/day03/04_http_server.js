//引入http模块
const http=require('http');
//创建web服务器
var server=http.createServer();
//设置web服务器的端口号，监听端口变化
server.listen(8080);

//接收浏览器的请求
//on 是一个事件，当有请求发生自动触发
//参数1: request 事件名称(请求)
//参数2: 通过回调函数来获取请求和做出响应
server.on('request',function(req,res){
  /*
  //req: 请求的对象
  //请求的URL
  console.log(req.url,req.method);
  //res: 响应的对象
  //设置响应的状态码和头信息
 
  res.writeHead(200,{
    Server:'web1903'
  });
  
  //设置响应的状态码为302，跳转到学子商城
  res.writeHead(302,{
    Location:'http://www.codeboy.com'
  });
  //设置响应的内容
  //res.write('this is homepage');
  //结束响应，发送响应的内容到浏览器
  res.end();
  */
  //判断请求的URL
  //根据请求的URL做出不同的响应
  if(req.url=='/login'){
    res.write('login');
  }else if(req.url=='/study'){
    res.writeHead(302,{
	  Location:'http://www.tmooc.cn'
	});
  }
  res.end()
});







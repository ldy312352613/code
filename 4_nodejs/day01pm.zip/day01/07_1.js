//(function(exports,require,module,__filename,__dirname){
//当前模块的完整路径和文件名称
//console.log(__filename);
//当前模块的完整路径 dir->directory目录
//console.log(__dirname);
//引入模块07_2.js
// ./  同一级目录
//把07_2.js模块导出的结果放入到变量中
var obj=require('./07_2.js');
console.log(obj);
console.log(obj.mya);
//调用函数fn
obj.fn();










//})
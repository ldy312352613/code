//创建buffer
var buf=global.Buffer.alloc(5,'a');
console.log(buf);
console.log(buf.toString());




//计算2019年5月1日10点30分23秒距离2019年12月25日相差的天数，小时，分钟，秒
var d1=new Date('2019/5/1 10:30:23');
var d2=new Date('2019/12/25');
//计算相差的毫秒数
var d=Math.abs(d1-d2);
//转成秒
d=Math.floor(d/1000);
//获取相差的天数
var day=Math.floor(d/(24*60*60));
//去除天数，剩下不满一天的秒数
var hours=d%(24*60*60);
//获取相差的小时
hours=Math.floor(hours/3600);
//去除小时，剩下不满一小时的秒数
var minutes=d%3600;
//获取相差的分钟
minutes=Math.floor(minutes/60);
//去除分钟，剩下的就是不满一分钟的秒数
var seconds=d%60;
console.log(day+'天'+hours+'小时'+minutes+'分钟'+seconds+'秒');



console.log('07_2.js');
var a=1;
var b=2;
var c=4;
function fn(){
  console.log(3);
}
//导出：公开哪些变量或者函数
//默认导出的是一个空对象
//添加导出的内容，就是往导出的对象中添加属性和方法
//module 指代当前的模块对象
//module.exports  导出的对象
module.exports.mya=a;
//练习：在07_2.js声明变量b，创建函数fn，导出变量和函数。
module.exports.b=b;
//导出函数：导出函数的结构，函数名称
module.exports.fn=fn;
exports.c=c;
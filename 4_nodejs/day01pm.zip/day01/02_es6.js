/*
//给形参设置默认值
function add(a,b,c=0){
  console.log(a+b+c);
}
add(2,5);
add(2,5,9);


//模板字符串
//如果价格超过20加5，否则正常
var price=30;
var title='华为P30';
var color='红色';
//创建模板字符串
var str=`
  商品名称：${title}
  商品价格：${price>20 ? (price+5) : price}
  商品颜色：${color}
  ${'欢迎购买'}
`;
console.log(str);
*/

var emp={
  ename:'tom',
  sex:1,
  birthday:'1997-9-20',
  salary:8000
}
console.log(`
  姓名：${emp.ename}
  性别：${emp.sex==0 ? '女' : '男'}
  生日：${emp.birthday}
  工资：${emp.salary}
`);








/*
global.console.log(1);
global.console.info(2);
global.console.warn(3);
global.console.error(4);
*/
//检测程序的耗时
global.console.time('for');//开始计时
for(var i=1;i<=10000;i++){
}
global.console.timeEnd('for');//结束计时
global.console.time('while');
var i=1;
while(i<=10000){
  i++;
}
global.console.timeEnd('while');

global.console.time('dowhile');
var i=1;
do{
  i++;
}while(i<=10000);
global.console.timeEnd('dowhile');



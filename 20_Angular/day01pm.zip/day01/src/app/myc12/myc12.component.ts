import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc12',
  templateUrl: './myc12.component.html',
  styleUrls: ['./myc12.component.css']
})
export class Myc12Component  {
  scoreList = [50, 90, 100, 70, 60]

}

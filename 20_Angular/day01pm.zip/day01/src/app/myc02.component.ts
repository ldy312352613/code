import { Component } from '@angular/core';

@Component({
  selector: 'app-myc02',
  template: `
    <h2>
      我的组件02
    </h2>
  `
})
export class MyComponent02 {

}
import { Component } from '@angular/core';

@Component({
  selector: 'app-myc04',
  //template: '',
  templateUrl: './myc04.component.html',
  //styles: ''
  styleUrls: ['./myc04.component.css']
})
export class MyComponent04 {
  
}
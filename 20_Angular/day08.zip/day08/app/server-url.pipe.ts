import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'serverUrl'
})
export class ServerUrlPipe {
  private url = 'http://www.codeboy.com/';

  transform(value, mode="prepend") {
    if(!value){  //防止还没有数据时NG执行的数据绑定
      return '';
    }
    if(mode==='prepend'){
      //把一个形如 img/1.jpg 的相对地址转换为绝对地址，形如 http://www.codeboy.com/img/1.jpg
      return this.url + value;
    }else if(mode==='replace'){
      //把一个形如 <div><img src="img/1.jpg">...<img src="img/2.jpg">...</div>的字符串替换为<div><img src="http://www.codeboy.com/img/1.jpg">...<img src="http://www.codeboy.com/img/2.jpg">...</div>
      return value.replace(/src="img/g, `src="${this.url}img`)
    }
  }
}

import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  //商品列表
  private productList = []
  //声明依赖：HttpClient 用于发起异步XHR请求
  constructor(private http: HttpClient) { }

  ngOnInit() {
    //异步请求产品列表
    let url = 'http://www.codeboy.com/data/product/list.php';
    this.http.get(url).subscribe((res:any)=>{
        //console.log(res);
        this.productList = res.data;
    })
  }

}

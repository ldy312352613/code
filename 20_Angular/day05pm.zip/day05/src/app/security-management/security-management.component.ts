import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-security-management',
  templateUrl: './security-management.component.html',
  styleUrls: ['./security-management.component.css']
})
export class SecurityManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

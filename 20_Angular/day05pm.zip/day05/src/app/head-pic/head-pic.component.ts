import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-head-pic',
  templateUrl: './head-pic.component.html',
  styleUrls: ['./head-pic.component.css']
})
export class HeadPicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  //将要显示的商品的编号
  private pidToShow;
  //将要显示的商品详情
  private productToShow = {}; //防止初始时页面错误
  //activate: 激活   
  //activated：被激活的，当前处于激活状态的
  //ActivatedRoute：当前浏览器中显示的那个路由
  constructor(private route: ActivatedRoute, private http: HttpClient) { }

  ngOnInit() {
    //组件初始化生命周期钩子中：
    //读取路由参数，根据此参数可能要执行服务器请求
    // console.log( this.route.params._value.pid )
    // console.log( this.route.params.value.pid )
    this.route.params.subscribe( (data)=>{
        console.log(data);
        this.pidToShow = data.pid;
        //向服务器发起异步HTTP请求，根据编号获取商品详情
        let url = 'http://www.codeboy.com/data/product/details.php?lid='+this.pidToShow;
        this.http.get(url).subscribe((res)=>{
              this.productToShow = res;
        })
    })
  }

}

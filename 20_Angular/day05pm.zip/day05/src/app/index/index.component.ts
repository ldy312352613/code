import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  doClick(){
    //编程方式：跳转到商品列表——依赖于路由器(Router)
    this.router.navigateByUrl('/product/list')
  }
}

import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TimeCheckGuard {
  constructor(private router: Router){}
  //能否激活路由：true表示允许激活；
  //false表示禁止访问路由
  canActivate(){
    let hour = new Date().getHours();
    if(hour>=18){
      console.log('现在是合法访问时间段')
      return true;
    }else {
      console.log('现在是禁止访问时间段')
      //this.router.navigateByUrl('/index')
      return false;
    }
  }
  
}

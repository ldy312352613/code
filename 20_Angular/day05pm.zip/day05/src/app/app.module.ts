import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { IndexComponent } from './index/index.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { UserCenterComponent } from './user-center/user-center.component';
import { RouterModule } from '@angular/router';
import { NotFoundComponent } from './not-found/not-found.component';
import { HttpClientModule } from '@angular/common/http';
import { MyInfoComponent } from './my-info/my-info.component';
import { HeadPicComponent } from './head-pic/head-pic.component';
import { SecurityManagementComponent } from './security-management/security-management.component';
import { TimeCheckGuard } from './time-check.guard';

/*路由词典*/
let routes = [
  {path:'', component:IndexComponent},
  {path:'index', component:IndexComponent},
  {path:'product/list', component:ProductListComponent},
  {path:'product/detail/:pid', component:ProductDetailComponent},
  {
    path:'user/center', 
    component:UserCenterComponent,
    canActivate: [ TimeCheckGuard ], //路由守卫
    //嵌套路由：在“用户中心”路由组件中存在多个嵌套的子路由组件
    children: [  
      {path:'',redirectTo: 'myinfo', pathMatch:'full'},
      //redirect：重定向到另一个路由地址，
      //pathMatch：full，要求路由地址完全匹配指定的地址，而不能只是包含指定的地址，如/user/center/abc就不能算做匹配/user/center
      {path:'myinfo',component:MyInfoComponent},
      {path:'headpic',component:HeadPicComponent},
      {path:'security',component:SecurityManagementComponent},
    ]
  },
  {path:'**', component:NotFoundComponent},
]

@NgModule({
  declarations: [
    AppComponent,
    IndexComponent,
    ProductListComponent,
    ProductDetailComponent,
    UserCenterComponent,
    NotFoundComponent,
    MyInfoComponent,
    HeadPicComponent,
    SecurityManagementComponent
  ],
  imports: [
    BrowserModule,
    /*注册路由词典*/
    RouterModule.forRoot(routes),
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

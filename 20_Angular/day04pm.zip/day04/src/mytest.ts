class Book {
  //class中的属性通常都应该声明为私有或被保护的
  //private price: number
  //private author:string
  protected price: number
  protected author: string

  //class中的方法通常都应该声明为公共
  public setPrice(p){//本类内部可以访问自己的私有属性
    if(p<0){
      return;
    }
    this.price = p;

  }
}

class ProgrammerBook extends Book {
  private lang:string = 'Java'

  print(){
    console.log(this.lang);
    console.log(this.price); //子类可以访问父类中的被保护成员
  }
}


class Student {
  read(){
    let book = new Book();
    //对象的内部“不应该”让外界随意赋值
    //book.price = -20; 
    //book.author = '   ' 
    book.setPrice(-200)
  }
}
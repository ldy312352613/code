import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {
  //商品列表
  private list = []
  //当前加载到的页号
  private pno = 0
  //没有更多数据可加载了
  private noMore = false
  //模拟的输入属性
  @Input()
  private uname:string;

  constructor(private http: HttpClient) {
    console.log('ProductListComponent对正在被创建')
    //console.log('this.uname:', this.uname); //undefined
  }

  //加载更多服务器端数据到this.list
  loadMore(){
    this.pno++;  //准备加载下一页
    let url = 'http://www.codeboy.com/data/product/list.php?pno='+this.pno;
    //发起异步请求
    this.http.get(url).subscribe( (res:any)=>{
        //console.log(res);
        //原有商品数组中拼接新加载到的商品
        this.list = this.list.concat( res.data )
        //判断还有没有更多数据
        if(this.pno>=res.pageCount){
          this.noMore = true
        }
    } )
  }

  ngOnChanges(){
    console.log('ProductListComponent输入属性值发生改变...')
  }
  ngOnInit() {
    console.log('ProductListComponent正在初始化...')
    //console.log('this.uname:', this.uname);
    this.loadMore();
  }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Myc01Component } from './myc01/myc01.component';
import { Myc02Component } from './myc02/myc02.component';
import { ProductListComponent } from './product-list/product-list.component';
import { SalePipe } from './sale.pipe';
import { IndexComponent } from './index/index.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { RouterModule } from '@angular/router';

// 路由词典
let routes = [
  {path:'index', component:IndexComponent},
  {path:'product/list', component:ProductListComponent},
  {path:'product/detail', component:ProductDetailComponent},
]

@NgModule({
  declarations: [
    AppComponent,
    Myc01Component,
    Myc02Component,
    ProductListComponent,
    SalePipe,
    IndexComponent,
    ProductDetailComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  // providers: [LoggerService],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

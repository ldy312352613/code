import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoggerService {
  //已经记录的日志的数量
  private count:number = 0

  constructor() { 
    console.log('一个LoggerService对象被创建了')
  }

  doLog( msg ){
    this.count++;
    console.log(`日志${this.count}： ${msg}`)
  }
}


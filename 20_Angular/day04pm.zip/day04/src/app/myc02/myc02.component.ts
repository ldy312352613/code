import { Component, OnInit } from '@angular/core';
import { LoggerService } from '../logger.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-myc02',
  templateUrl: './myc02.component.html',
  styleUrls: ['./myc02.component.css'],
  // providers: [LoggerService]
})
export class Myc02Component{
  //在构造方法中声明组件所依赖的服务
  //会由服务提供者注入该服务对象    
  constructor(
    private logger: LoggerService ,
    private http: HttpClient
  ) { 
  }

  doClick(){
    this.logger.doLog('MyC02在做日志')
  }

  loadData(){  //使用httpClient服务异步请求服务器端数据
    let url = 'http://www.codeboy.com/data/product/list.php';
   
    var result = this.http.get(url)
    //console.log(result)  //此时并未真正发起HTTP请求！！
    //result是一个Rx.js提供的Observable对象
    result.subscribe( (res)=>{
      console.log('接收到订阅的数据：')
      console.log(res)
    } )
  }
}








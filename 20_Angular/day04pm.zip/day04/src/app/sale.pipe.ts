import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sale'
})
export class SalePipe implements PipeTransform {

  transform(value) {
    if(value == 1){
      return '是'
    }else if(value == 0){
      return '否'
    }else {
      return '未知'
    }
  }

}

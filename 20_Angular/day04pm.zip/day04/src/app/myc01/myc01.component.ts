import { Component, OnInit } from '@angular/core';
import { LoggerService } from '../logger.service';

@Component({
  selector: 'app-myc01',
  templateUrl: './myc01.component.html',
  styleUrls: ['./myc01.component.css'],
  // providers: [LoggerService]
})
export class Myc01Component {
  //private logger: LoggerService = new LoggerService();

  /*
  private logger: LoggerService
  constructor(logger: LoggerService) {
    this.logger = logger;
  }
  */
  constructor(private logger: LoggerService){
    //依赖注入
  }

  doClick(){
    this.logger.doLog('MyC01在做日志')
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc03-card',
  templateUrl: './myc03-card.component.html',
  styleUrls: ['./myc03-card.component.scss'],
})
export class Myc03CardComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

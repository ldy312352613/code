import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc04-item',
  templateUrl: './myc04-item.component.html',
  styleUrls: ['./myc04-item.component.scss'],
})
export class Myc04ItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

  jump(){
    location.href="http://www.tmooc.cn"
  }
}

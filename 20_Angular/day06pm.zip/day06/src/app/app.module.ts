import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppComponent } from './app.component';
import { Myc01IconBtnComponent } from './myc01-icon-btn/myc01-icon-btn.component';
import { Myc02AlertComponent } from './myc02-alert/myc02-alert.component';
import { Myc03CardComponent } from './myc03-card/myc03-card.component';
import { Myc04ItemComponent } from './myc04-item/myc04-item.component';

@NgModule({
  declarations: [
    AppComponent,
    Myc01IconBtnComponent,
    Myc02AlertComponent,
    Myc03CardComponent,
    Myc04ItemComponent
  ],
  entryComponents: [],
  imports: [BrowserModule, IonicModule.forRoot()],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}

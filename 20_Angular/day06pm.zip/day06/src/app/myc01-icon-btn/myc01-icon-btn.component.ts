import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc01-icon-btn',
  templateUrl: './myc01-icon-btn.component.html',
  styleUrls: ['./myc01-icon-btn.component.scss'],
})
export class Myc01IconBtnComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

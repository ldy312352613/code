import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-myc02-alert',
  templateUrl: './myc02-alert.component.html',
  styleUrls: ['./myc02-alert.component.scss'],
})
export class Myc02AlertComponent {

  constructor(private alertController: AlertController) { }

  doClick1(){
    //弹出一个确认按钮的警告框
    this.alertController.create({
      header: '用户卡号',   //主标题
      subHeader: '副标题',  //副标题
      message: '您的卡号为：12345677890', //内容
      buttons: ['确定']     //按钮
    }).then((dialog)=>{
        dialog.present();  //呈现对话框
    })
  }

  doClick2(){
    this.alertController.create({
      header:'删除确认',
      message: '您确认删除吗？此操作不可恢复！',
      buttons: [
        {  //第一个按钮上的文字及处理函数
          text: '取消',  
          role: 'cancel',
          handler: ()=>{ console.log('用户点击了取消') }
        },
        {  //第二个按钮上的文字及处理函数
          text: '确定',
          handler: ()=>{ console.log('用户点击了确定删除') }
        }
      ]
    }).then((dialog)=>{
      dialog.present(); //显示出对话框
    })
  }

  doClick3(){

  }

}

import { Injectable } from '@angular/core';

//所有的服务对象都可以被注入给其它组件/指令/服务....
//服务提供者：ServiceProvider，负责创建服务对象，
//并注入给需要该服务对象的地方
@Injectable({
  providedIn: 'root'
})
export class LoggerService {
  mode = 'development' //项目运行与开发模式，就做日志   17:32
  //mode = 'production'//项目运行与开发模式，就不做日志或简单日志

  log(msg){
    if(this.mode == 'production'){
      console.log('精简系统日志：', msg);
    }else if(this.mode == 'development'){
      console.log('====================================');
      console.log('复杂系统日志：', msg);
      console.log('====================================');
    }
  }
}

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sex'
})
export class SexPipe{
  //所有的管道必须提供一个transform的方法
  //用于获得数据，转换为另一种格式
  transform(val, lang='zh'){
    if(lang=='zh'){
        if(val==0){
          return  '女'
        }else if(val==1){
          return  '男'
        }else {
          return  '不详'
        }
    }else if(lang=='en'){
        if(val==0){
          return  'Female'
        }else if(val==1){
          return  'Male'
        }else {
          return  'NA'
        }
    }
    
  }

}



// TS中的接口
interface Runnable {
  run()  //接口中的方法都没有主体
  stop() //接口中的方法都没有主体
}

//类不能“继承”接口，要“实现”接口
class Car implements Runnable {
  run(){
    console.log('汽车用四个轮子跑...')
  }
  stop(){

  }
}

class Boy implements Runnable{
  run(){
    console.log('小朋友用双腿跑...')
  }
  stop(){
    
  }
}



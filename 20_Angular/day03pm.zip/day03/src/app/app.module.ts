import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Myc01Component } from './myc01/myc01.component';
import { Myc02HomeworkComponent } from './myc02-homework/myc02-homework.component';
import { Myc03PipeComponent } from './myc03-pipe/myc03-pipe.component';
import { SexPipe } from './sex.pipe';
import { ZzmmPipe } from './zzmm.pipe';
import { ParentComponent } from './parent/parent.component';
import { ChildUpdateComponent } from './child-update/child-update.component';
import { ChildBlogComponent } from './child-blog/child-blog.component';
import { ChildPhotoComponent } from './child-photo/child-photo.component';
import { Myc04Component } from './myc04/myc04.component';

@NgModule({
  declarations: [
    AppComponent,
    Myc01Component,
    Myc02HomeworkComponent,
    Myc03PipeComponent,
    SexPipe,
    ZzmmPipe,
    ParentComponent,
    ChildUpdateComponent,
    ChildBlogComponent,
    ChildPhotoComponent,
    Myc04Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

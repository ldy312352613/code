import { Component, OnInit } from '@angular/core';
import { LoggerService } from '../logger.service';

@Component({
  selector: 'app-myc04',
  templateUrl: './myc04.component.html',
  styleUrls: ['./myc04.component.css']
})
export class Myc04Component {
  count:number = 1
  logger = null;

  //此处会发生“DI”——依赖注入现象
  constructor(logger:LoggerService){
    console.log('一个MyC04Component对象构建出来了....')
    console.log(logger)
    this.logger = logger;
  }

  inc(){
    this.logger.log('用户增加了一个商品')
    //var logger = new LoggerService();
    //logger.log('用户增加了一个商品');
    /*
    console.log('====================================');
    console.log('用户增加了一个商品');
    console.log('====================================');
    */
    this.count++;
  }

  desc(){
    this.logger.log('用户减少了一个商品')
    /*
    console.log('====================================');
    console.log('用户减少了一个商品');
    console.log('====================================');
    */
    this.count--;
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc01',
  templateUrl: './myc01.component.html',
  styleUrls: ['./myc01.component.css']
})
export class Myc01Component{
  count: number = 10000
  list: string[] = ['商品1','商品2','商品3']

  doClick(ev, el): void {
    this.count++;
    console.log(el);
  }
}

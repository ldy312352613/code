import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent {
  //父组件中的模型数据
  myName:string = '苍茫大地'

  //处理子组件事件的方法
  doUnameEvent( data ){
    console.log('父组件正在处理子组件事件：', data)
    //把子组件传递给父组件的数据加以利用
    this.myName = data;
  }
}

import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-child-photo',
  templateUrl: './child-photo.component.html',
  styleUrls: ['./child-photo.component.css']
})
export class ChildPhotoComponent {
  //输入型属性
  @Input()
  uname: string

  @Input()
  age:number

}


import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child-update',
  templateUrl: './child-update.component.html',
  styleUrls: ['./child-update.component.css']
})
export class ChildUpdateComponent {
  userInput:string = ''
  //事件发射器属性：可用于对外界发射事件对象
  @Output()   //输出型属性，必须是“事件发射器”
  unameEvent = new EventEmitter(); 

  doClick(){
    console.log('用户输入了：', this.userInput)
    //向外界发射事件，并携带数据
    this.unameEvent.emit( this.userInput );
  }
}

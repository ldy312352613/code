import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'zzmm'
})
export class ZzmmPipe {
  /*
  *val: 要转换形式的目标数据
  *short：是否采用简短形式
  */
  transform(val, short:boolean=true){
    var result = '';
    if(val==1){
        if(short){
          result = '党员'
        }else {
          result = '中国共产党党员'
        }
    }else if(val==2){
        if(short){
          result = '团员'
        }else {
          result = '中国共青团团员'
        }
    }else if(val==3){
        if(short){
          result = '群众'
        }else {
          result = '中国人民群众'
        }
    }else {
        result = '未知'
    }
    return result;
  }

}

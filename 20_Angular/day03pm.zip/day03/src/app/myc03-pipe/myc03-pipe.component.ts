import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc03-pipe',
  templateUrl: './myc03-pipe.component.html',
  styleUrls: ['./myc03-pipe.component.css']
})
export class Myc03PipeComponent {
  userSex:number = 0  //来自数据库中的数据
  
  //所有员工的政治面貌
  employeesZzmm = [1, 1, 3, 2, 2, 9]

}

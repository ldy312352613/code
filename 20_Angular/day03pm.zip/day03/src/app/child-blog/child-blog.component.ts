import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-child-blog',
  templateUrl: './child-blog.component.html',
  styleUrls: ['./child-blog.component.css']
})
export class ChildBlogComponent {
  //声明子组件的专有属性：userName
  @Input()   //输入型属性，可以被父组件输入值
  userName:string   //子组件属性的值来自于父组件
}

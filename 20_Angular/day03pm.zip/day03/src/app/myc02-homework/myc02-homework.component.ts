import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc02-homework',
  templateUrl: './myc02-homework.component.html',
  styleUrls: ['./myc02-homework.component.css']
})
export class Myc02HomeworkComponent {
  uname: string = ''                        //用户名
  unameMsg: string = '用户名长度在3~9位之间'  //用户名后的提示消息
  unameClass: string = 'primary'            //用户名消息样式
  upwd: string = ''

  //处理“提交”按钮的单击事件
  doSubmit(): void {
    console.log('用户名：', this.uname)
    console.log('密码：', this.upwd)
    //TODO: 执行异步请求，提交给服务器
  }
  //处理“用户名”输入内容改变事件
  doUnameChange():void {             
    if(this.uname.length<3){
      this.unameMsg = '用户名长度太短了'
      this.unameClass = 'error'
    }else if(this.uname.length>9){
      this.unameMsg = '用户名长度太长了'
      this.unameClass = 'error'
    }else {
      this.unameMsg = '用户名长度合适'
      this.unameClass = 'success'
    }
  }
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { Myc01HomeworkComponent } from './myc01-homework/myc01-homework.component';
import { Myc02DirectiveComponent } from './myc02-directive/myc02-directive.component';
import { NeedStrongDirective } from './need-strong.directive';
import { Myc03ModelComponent } from './myc03-model/myc03-model.component';
import { Myc04TodolistComponent } from './myc04-todolist/myc04-todolist.component';

@NgModule({
  declarations: [
    AppComponent,
    Myc01HomeworkComponent,
    Myc02DirectiveComponent,
    NeedStrongDirective,
    Myc03ModelComponent,
    Myc04TodolistComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

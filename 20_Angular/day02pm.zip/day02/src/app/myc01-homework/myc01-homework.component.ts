import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc01-homework',
  templateUrl: './myc01-homework.component.html',
  styleUrls: ['./myc01-homework.component.css']
})
export class Myc01HomeworkComponent  {
  productList:Array<Object> = [
    {pid:1001, pname:'联想小新', pic:'../../assets/1.jpg', isOnsale:true, birthday: 0},
    {pid:1002, pname:'戴尔7000系列', pic:'../../assets/2.jpg', isOnsale:false, birthday: 3600*1000}, 
    {pid:1003, pname:'苹果MacBook', pic:'../../assets/3.jpg', isOnsale:false, birthday: 3600*1000*24},
    {pid:1004, pname:'明基探路者', pic:'../../assets/4.jpg', isOnsale:true, birthday: 3600*1000*24*365},
  ]
  
  //用户等级
  userLevel:number = 3

  //强调显示的样式对象
  myStyleObj = {
    'font-weight': 'bold',
    'color': 'red'
  }

  //控制样式class的对象
  myClassObj = {
    'show': true,
    'hide': false
  }


  doDelete(i){
    console.log(i);
    //删除模型数据（数组）中的第i个元素
    this.productList.splice(i, 1);
  }
}

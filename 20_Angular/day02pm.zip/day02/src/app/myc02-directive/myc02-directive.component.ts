import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc02-directive',
  templateUrl: './myc02-directive.component.html',
  styleUrls: ['./myc02-directive.component.css']
})
export class Myc02DirectiveComponent{
  
  //themeObj = 'greenTheme';
  
  themeObj = {
    blueTheme: false,
    greenTheme: false,
    darkTheme: true
  }

  changeTheme(theme){
    for(let p in this.themeObj){
      if(p===theme){
        this.themeObj[p] = true;
      }else {
        this.themeObj[p] = false;
      }
    }
  }
}

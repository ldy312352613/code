import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appNeedStrong]'
})
export class NeedStrongDirective {

  //依赖注入——后续课程会继续讲解此特性
  constructor(el:ElementRef) { 
    //参数el指代应用了当前指令的HTML元素
    console.log('指令的构造方法：', el);
    el.nativeElement.style.background='#ffa';
    el.nativeElement.style.color='#aa0';
    el.nativeElement.style.fontWeight='bold';
  }

}

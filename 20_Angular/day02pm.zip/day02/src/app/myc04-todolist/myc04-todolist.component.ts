import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc04-todolist',
  templateUrl: './myc04-todolist.component.html',
  styleUrls: ['./myc04-todolist.component.css']
})
export class Myc04TodolistComponent {
  //Model数据
  todoList = [ '开会', '采购' ];   //待办事项
  userInput = '';   //用户输入
  userName = 'tom CRuise'
 
  doAdd(){
    this.todoList.push(this.userInput);
    this.userInput = ''; //清除已有的输入内容
  }
  doDelete(i){
    this.todoList.splice(i, 1);
  }
}

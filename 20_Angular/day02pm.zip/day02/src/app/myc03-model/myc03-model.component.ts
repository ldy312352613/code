import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc03-model',
  templateUrl: './myc03-model.component.html',
  styleUrls: ['./myc03-model.component.css']
})
export class Myc03ModelComponent{
  //Model数据
  userName = 'dingding'
  userPwd = ''
  userPwdMsg = ''

  doChange(){
    console.log(this.userName);
  }

  doPwdChange(){
    if(this.userPwd===''){
      this.userPwdMsg = '密码不能为空'
    }else if(this.userPwd.length<6){
      this.userPwdMsg = '密码不能少于6位'
    }else if(this.userPwd.length>12){
      this.userPwdMsg = '密码不能长于12位'
    }else {
      this.userPwdMsg = '密码长度合法'
    }
  }
}


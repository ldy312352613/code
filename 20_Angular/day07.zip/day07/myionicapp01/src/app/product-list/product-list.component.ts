import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss'],
})
export class ProductListComponent implements OnInit {
  private productList = [];
  private pno = 0;
  private serverUrl = 'http://www.codeboy.com/'
  private hasMore = true;

  constructor(private http: HttpClient, private nav: NavController) { }

  ngOnInit() {
    this.loadData();
  }

  loadData(e?:any){
    this.pno++;
    let url = "http://www.codeboy.com/data/product/list.php?pno="+this.pno;
    this.http.get(url).subscribe((res:any)=>{
        this.productList=  this.productList.concat(res.data);
        if(e){
          e.target.complete();
        }
        if(this.pno>=res.pageCount){
          this.hasMore = false;
        }
    })
  }
  back(){
    this.nav.back();
  }

}

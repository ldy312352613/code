import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss'],
})
export class IndexComponent implements OnInit {
  @ViewChild('slides', {static:true})
  private slides: any;

  private slideOpts = {
    initialSlide: 0,
    speed: 400
  }
  constructor() { }

  ngOnInit() {
    this.slides.startAutoplay();
  }

}

import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  private userName = '';
  private userPwd = '';

  constructor(private alertController: AlertController) { }

  ngOnInit() {}

  doLogin(){
    this.alertController.create({
      header: '登录结果',
      message: '登录成功！',
      buttons: ['确定']
    }).then((dialog)=>{
      dialog.present();
    })
  }

}

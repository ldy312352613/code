import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'serverUrl'
})
export class ServerUrlPipe implements PipeTransform {
  private serverUrl = 'http://www.codeboy.com/'
  transform(value: string, ...args: any[]): any {
    if(!value){
      return '';
    }
    return value.replace(/src="img/g, `src="${this.serverUrl}img`);
  }

}

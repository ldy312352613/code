import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppComponent } from './app.component';
import { IndexComponent } from './index/index.component';
import { HomeComponent } from './home/home.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { HttpClientModule } from '@angular/common/http';
import { BuyCountComponent } from './buy-count/buy-count.component';
import { ServerUrlPipe } from './server-url.pipe';
import { LoginComponent } from './login/login.component';
import { CartComponent } from './cart/cart.component';

let routes = [
  {
    path: '', 
    component: HomeComponent,
    children: [
      // {path: '', redirectTo: 'index', pathMatch:'full'},
      {path: '', component: IndexComponent},
      {path: 'product-list', component: ProductListComponent},
      {path: 'product-detail/:pid', component: ProductDetailComponent},
      {path: 'login', component: LoginComponent},
      {path: 'cart', component: CartComponent},
      {path: '**', component: NotFoundComponent},
    ]
  }
]
@NgModule({
  declarations: [
    AppComponent, 
    IndexComponent, 
    HomeComponent, 
    ProductListComponent, 
    ProductDetailComponent,
    NotFoundComponent,
    BuyCountComponent,
    CartComponent,
    ServerUrlPipe,
    LoginComponent
  ],
  entryComponents: [],
  imports: [
    BrowserModule, 
    IonicModule.forRoot(), 
    RouterModule.forRoot(routes), 
    FormsModule, 
    HttpClientModule,
  ],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}

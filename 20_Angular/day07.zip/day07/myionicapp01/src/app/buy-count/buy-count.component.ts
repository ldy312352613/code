import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buy-count',
  templateUrl: './buy-count.component.html',
  styleUrls: ['./buy-count.component.scss'],
})
export class BuyCountComponent implements OnInit {
  private count =0
  constructor() { }

  ngOnInit() {}

}

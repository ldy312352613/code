import { Component, OnInit, ViewChild } from '@angular/core';
import { NavController, IonSlides } from '@ionic/angular';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss'],
})
export class ProductDetailComponent implements OnInit {
  private pid = 0;
  private product = {}
  private serverUrl = 'http://www.codeboy.com/'
  @ViewChild(IonSlides, {static:true})
  private slides: IonSlides;
  private slideOpts = {
    initialSlide: 0,
    speed: 400
  }

  constructor(private nav: NavController,private route: ActivatedRoute, private router: Router, private http: HttpClient) { }

  ngOnInit() {
    let url = 'http://www.codeboy.com/data/product/details.php?lid=';
    this.route.params.subscribe((data)=>{
      this.pid = data.pid;
      this.http.get(url+this.pid).subscribe((res:any)=>{
        this.product = res.details;
        console.log(this.product)
        this.slides.startAutoplay();
      })
    })
  }
  back(){
    this.nav.back();
  }
}

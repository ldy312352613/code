import {createStackNavigator, createAppContainer} from 'react-navigation'
import LoginScreen from './src/components/LoginScreen';
import MainScreen from './src/components/MainScreen';
import ProductListScreen from './src/components/ProductListScreen';
import ProductDetailScreen from './src/components/ProductDetailScreen';

//创建路由词典 —— 栈式导航器
let routes = createStackNavigator({
  //path:'xxx', component: Xxx
  productList: ProductListScreen,
  main: MainScreen,
  login: LoginScreen,   //第一个路由即是“首屏内容”
  productDetail: ProductDetailScreen,
}, 
// {
//   initialRouteName: 'login'
// }
)

//创建主组件(自带页头)，在其中注册路由词典
export default createAppContainer( routes )

var content = `
  <div><p></p>
    <img src="img/aa/bb/1.jpg">
    <hr>
    <img src="img/aa/bb/2.jpg">
    <img src="img/aa/bb/3.jpg">
  </div>
`
//返回当前字符串中所有的正则匹配项
let arr = content.match( /img\/\S*\.jpg/g )
console.log(arr)
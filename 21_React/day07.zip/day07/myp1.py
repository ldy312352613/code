print('hello');
print('world');
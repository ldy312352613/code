import React from 'react'
import {View, Button} from 'react-native'

export default class MyC02 extends React.Component{
  constructor(){
    super()
  }
  doPress(){
    alert('按钮被点击了一次1')  //弹出原生警告框
    //console.log默认在手机的操作系统控制台输出——可以把手机控制台输出使用WebWorker导出到一个浏览器控制台——称为“JS远程调试”
    console.log('按钮被点击了一次2') 
    //练习：在一个Text中显示一个计数器，点击一次Button，计数器+1      
  }
  render(){
    return (
      <View>
        {/* <Button>按钮1</Button> */}
        <Button title="提交1" />
        <Button title="提交2" onPress={this.doPress}/>
        <Button title="提交3" onPress={this.doPress} color="red"/>
        {/* <Button title="提交4" onPress={this.doPress} disabled="true"/> */}
        <Button title="提交4" onPress={this.doPress} disabled={true}/>
      </View>
    )
  }
}
import React from 'react'
import {Text, View, TextInput, Switch} from 'react-native'

export default class MyC05 extends React.Component{
  constructor(){
    super()
    this.doUnameChange = this.doUnameChange.bind(this)
    this.state = {
      uname: ''
    }
  }
  doUnameChange(val){
    //onChangeText事件的监听函数，参数是当前用户输入值，不是Event对象！！！
    this.setState({     //把用户输入保存入状态
      uname: val,
      isOnline: true
    })
  }
  doValueChange = (val)=>{
    this.setState({
      isOnline: val
    })
  }
  render(){
    return (
      <View>
        <Text>请输入用户名：</Text>
        <TextInput placeholder="请输入用户名" value={this.state.uname} onChangeText={this.doUnameChange}  style={{borderColor:'gray', borderWidth: 1}}/>

        <Text>是否保持在线状态？</Text>
        <Switch value={this.state.isOnline} onValueChange={this.doValueChange} />

      </View>
    )
  }
}
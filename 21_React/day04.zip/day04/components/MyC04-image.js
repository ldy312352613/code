import React from 'react'
import {Text, View, Image, ScrollView, ImageBackground} from 'react-native'

export default class MyC04 extends React.Component{
  constructor(){
    super()
  }

  render(){     
    return (
      <ScrollView>      
        {/* <Image source="./assets/logo.png"/> */}
        {/* require()会在编译阶段把图片打包到apk程序中 */}
        <Image source={require('./assets/logo.png')}/>
        <Image style={{width: 300}} source={require('./assets/logo.png')}/>
        <Image style={{width: 300, height:100}} source={require('./assets/logo.png')}/>
        <Image style={{width: 336, height:84}} source={require('./assets/logo.png')}/>

        {/* <Image source={{uri:'http://cdn.tmooc.cn/tmooc-web/courseImg/2018/6/15//25D64D24BF544A2FB2FFD0FA328B70F0.png'}}/> */}
        {/* <Image style={{width: 300}} source={{uri:'http://cdn.tmooc.cn/tmooc-web/courseImg/2018/6/15//25D64D24BF544A2FB2FFD0FA328B70F0.png'}}/> */}
        <Image style={{width: 320, height:180}} source={{uri:'http://cdn.tmooc.cn/tmooc-web/courseImg/2018/6/15//25D64D24BF544A2FB2FFD0FA328B70F0.png'}}/>
        <Image resizeMode="stretch" style={{width: 100, height:200}} source={{uri:'http://cdn.tmooc.cn/tmooc-web/courseImg/2018/6/15//25D64D24BF544A2FB2FFD0FA328B70F0.png'}}/>

        <View style={{height: 200}}>
          {/* 有背景图片的文字 */}
          <ImageBackground source={require('./assets/bg.png')} style={{width:'100%', height: '100%'}}>
              <Text style={{color:'#fff'}}>这里是有背景图片的文字</Text>
          </ImageBackground>
        </View>
      </ScrollView>
    )
  }
}
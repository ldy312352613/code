import React from 'react'
import {Text, View, Button} from 'react-native'

export default class MyC03 extends React.Component{
  constructor(){
    super()
    this.doPress = this.doPress.bind(this)  //事件监听函数绑定this的指向
    this.state = {    //初始化状态数据
      count: 0
    }
  }
  doPress(){
    //修改状态数据
    let count = this.state.count;
    count++;
    this.setState({ count  })
  }
  render(){
    return (
      <View>
        <Text>{this.state.count}</Text>
        <Button title="点击计数" onPress={this.doPress}/>
      </View>
    )
  }
}
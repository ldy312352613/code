import React from 'react'
import {Text, View} from 'react-native'

export default class MyC01 extends React.Component{
  constructor(){
    super()
  }

  render(){
    let str = 'MM\nNN';
    let longStr = '2Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt magnam nulla recusandae excepturi odio ex aliquam delectus deleniti accusantium obcaecati iure aperiam repudiandae ipsum sunt animi explicabo molestias ab voluptas.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus magnam assumenda voluptas aperiam ducimus enim eos id neque pariatur officia cum molestiae impedit. Quaerat dignissimos assumenda nostrum delectus ipsum veritatis.	Lorem ipsum dolor sit amet, consectetur adipisicing elit. A ipsa harum exercitationem accusamus molestias tempore qui expedita. Incidunt rerum assumenda consectetur molestiae voluptatibus necessitatibus nulla esse nesciunt natus repellat dolor.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente asperiores cumque illo error minus numquam recusandae quod nisi architecto nihil itaque debitis quam explicabo facere culpa ducimus eius. Voluptas autem.	';
    return (
      <View>
        {/* <Text>AA<br/>BB</Text> */}
        {/* <Text>CC\nDD</Text> */}
        <Text>XX{'\n'}YY</Text>
        <Text>{str}</Text>
        <Text numberOfLines={3} ellipsizeMode='tail'>{longStr}</Text>
      </View>
    )
  }
}
/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React from 'react';

import {Text, StyleSheet} from 'react-native'
//内部样式
let myStyles = StyleSheet.create({
  /*.danger {
  }*/
  danger: {
    color: '#0ff',
    textDecorationLine:'line-through'
  },
  success: {
    color: '#f0f',
    textDecorationLine:'line-through'
  }
})

export default class App extends React.Component{
  constructor(){
    super()
    this.state = {
      styleObj: {
        color: 'red'
      }
    }
  }
  render(){
    return (
      <Text style={ {color:'blue', fontSize: 20} }>
        AA
        <Text style={myStyles.danger}>Hello World</Text>
        BB
        <Text style={myStyles.danger}>达内欢迎您</Text>
        CC
      </Text>
    )
  }
}
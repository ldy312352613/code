/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React from 'react';
import MyC01 from './components/MyC01';
import MyC02 from './components/MyC02-button';
import MyC03 from './components/MyC03-exercise';
import MyC04 from './components/MyC04-image';
import MyC05 from './components/MyC05-input';

export default class App extends React.Component{
  constructor(){
    super()
  }
  render(){
    return (
      // <MyC01/>
      // <MyC02/>
      // <MyC03/>
      // <MyC04/>
      <MyC05/>
    )
  }
}
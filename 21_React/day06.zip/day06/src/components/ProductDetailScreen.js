import React from 'react'
import {View, Text} from 'react-native'

export default class ProductDetailScreen extends React.Component{
  /*对象属性*/
  static navigationOptions = {
    title: '商品详情'
  }

  /*对象构造方法*/
  constructor(){
    super()
    this.state = {

    }
  }

  /*对象方法*/
  render(){
    return (
      <View>
        <Text>商品详情界面</Text>
      </View>
    )
  }
}
import React from 'react'
import {View, Text, FlatList, Image, Button, ActivityIndicator} from 'react-native'

export default class ProductListScreen extends React.Component{
  /*对象属性*/
  static navigationOptions = {
    title: '商品列表'
  }
  static serverUrl = 'http://www.codeboy.com/'
  static prodoctListUrl = 'http://www.codeboy.com/data/product/list.php?pno='    //静态属性，所有的组件实例共用
  pno = 0  //实例属性，即将要加载的数据页号

  /*对象构造方法*/
  constructor(){
    super()
    this.state = {
      plist: []   //商品数组
    }
  }

  /*对象方法*/
  componentDidMount(){  //当组件加载完成，异步请求服务器端商品列表数据
    this.pno++
    fetch(ProductListScreen.prodoctListUrl)
      .then((res)=>{return res.json()})
      .then((result)=>{
        this.setState({ //把服务器响应数据保存入状态数据
          plist: result.data
        })
      })
      .catch((err)=>{ alert(err) })
  }
  _renderItem=(data)=>{   //渲染出一个列表项
    //console.log('一个列表项对应的数据：', data)
    //data:{index: 0, item: {笔记本对象} }
    return (
      <View style={{flexDirection:'row', padding:10, alignItems:'center'}}>
        <Image source={{uri: ProductListScreen.serverUrl + data.item.pic}} style={{width:80, heigt:80}}/>
        <View style={{flex:1}}>
          <Text numberOfLines={1} ellipsizeMode="tail">{data.item.title}</Text>
        </View>
        <Button title="查看详情"/>
      </View>
    )
  }
  render(){
    return (
      <FlatList data={this.state.plist} renderItem={this._renderItem}>
      </FlatList>
    )
  }
}
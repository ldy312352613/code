import React from 'react'
import MyC01 from './src/components/myc01';
import MyC02 from './src/components/myc02-indicator';
import MyC03 from './src/components/myc03-touchable';
import MyC04 from './src/components/myc04-list';
import MyC05 from './src/components/myc05-list';
import MyC06 from './src/components/myc06-list';
import MyC07 from './src/components/myc07-flex';
import MyC08 from './src/components/myc08-flex';
import MyC09 from './src/components/myc09-flex';

export default class App extends React.Component{
  render(){
    return (
      // <MyC01/>
      // <MyC02/>
      // <MyC03/>
      // <MyC04/>
      // <MyC05/>
      // <MyC06/>
      // <MyC07/>
      // <MyC08/>
      <MyC09/>
    )
  }
}     

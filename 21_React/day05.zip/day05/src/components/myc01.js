import React from 'react'
import {View, Text} from 'react-native'

export default class MyC01 extends React.Component{
  constructor(){
    super()
  }
  render(){
    return (
      <View>
        <Text>我的组件</Text>
      </View>
    )
  }
}
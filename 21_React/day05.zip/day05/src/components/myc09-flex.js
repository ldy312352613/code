import React from 'react'
import {View, StyleSheet, Image, Text, TouchableOpacity} from 'react-native'

let ss = StyleSheet.create({
  box: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    padding: 15
  },
  title: {
    fontSize: 30,
    color: '#73879c'
  }
})

export default class MyC09 extends React.Component{
  render(){          
    return (
      <View style={ss.box}>
        <Image source={require('../assets/logo.png')}/>
        <Text style={ss.title}>后台管理系统</Text>
      </View>
    )
  }
}



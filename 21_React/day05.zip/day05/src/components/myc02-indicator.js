import React from 'react'
import {View, Text, ActivityIndicator, Button} from 'react-native'

export default class MyC02 extends React.Component{
  constructor(){
    super()
    this.state = {
      isLoading: true
    }
  }

  _onPress = ()=>{
    let isLoading = this.state.isLoading;
    isLoading = !isLoading;
    this.setState({ isLoading })
  }
  render(){
    return (
      <View>
        <Text>活动指示器</Text>
        <ActivityIndicator/>
        <ActivityIndicator size="large"/>
        <ActivityIndicator size="large" color="#0f0"/>
        <ActivityIndicator size="large" color="#f00"/>
        <ActivityIndicator size="large" color="#00f" animating={false}/>

        <View style={{height:1, backgroundColor:'#333'}}></View>

        <ActivityIndicator size="large" color="purple" animating={this.state.isLoading}/>

        <Button title="隐藏/显示活动指示器" onPress={this._onPress}/>
      </View>
    )
  }
}
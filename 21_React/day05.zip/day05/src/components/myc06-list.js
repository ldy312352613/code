import React from 'react'
import {View, Text, FlatList, ActivityIndicator} from 'react-native'

export default class MyC06 extends React.Component{

  constructor(){
    super()
    this.state = {
      list: ['丁丁', '当当', '豆豆']
    }
  }
  _renderItem = (data)=>{
    //data: {index:1, item: '豆豆'}
    return (
      <Text>{data.item}</Text>
    )
  }
  _listHeader(){
    return (
      <Text style={{fontSize:30, textAlign:'center'}}>学生列表</Text>
    )
  }
  _listFooter(){
    return (
      <View>
        <ActivityIndicator size="large" animating={true}></ActivityIndicator>
        <Text>加载中请稍候...</Text>
      </View>
    )
  }
  render(){
    return (
      <FlatList data={this.state.list} renderItem={this._renderItem} keyExtractor={  (item, index)=>index+'' }  ListHeaderComponent={this._listHeader} ListFooterComponent={this._listFooter}></FlatList>
    )
  }
}



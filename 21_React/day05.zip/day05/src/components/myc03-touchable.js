import React from 'react'
import {View, Text, Image, TouchableOpacity} from 'react-native'

export default class MyC03 extends React.Component{
  constructor(){
    super()
  }
  render(){
    return (
      <View>
        <Text>可被触摸的组件</Text>
        <Image source={require('../assets/logo.png')}/>

        <TouchableOpacity>
            <Image source={require('../assets/logo.png')}/>
        </TouchableOpacity>
       
        <TouchableOpacity>
            <Text>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Id tempore impedit alias, eaque ratione hic doloremque eius, maxime adipisci aperiam minima nam itaque enim provident fugit asperiores. Adipisci, modi eum. Lorem</Text>
        </TouchableOpacity>
      </View>
    )
  }
}
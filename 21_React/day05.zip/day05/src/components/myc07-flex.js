import React from 'react'
import {View, Text, FlatList, ActivityIndicator} from 'react-native'

export default class MyC07 extends React.Component{

  constructor(){
    super()
  }
  render(){          
    return (
      // <View style={{flex:1, flexDirection:'row'}}>
      //   <Text style={{flex:1, backgroundColor:'#faa'}}>1</Text>
      //   <Text style={{flex:2, backgroundColor:'#afa'}}>2</Text>
      //   <Text style={{flex:1, backgroundColor:'#aaf'}}>3</Text>
      // </View>
      <View style={{flex:1, alignItems:'center', justifyContent:'space-around'}}>
        <Text style={{width:50, height:50, backgroundColor:'#faa'}}>1</Text>
        <Text style={{width:100, height:100, backgroundColor:'#afa'}}>2</Text>
        <Text style={{width:150, height:150, backgroundColor:'#aaf'}}>3</Text>
      </View>
    )
  }
}



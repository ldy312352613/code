import React from 'react'
import {View, Text, FlatList, TouchableOpacity} from 'react-native'

export default class MyC04 extends React.Component{
  constructor(){
    super()
    this.state = {
      plist: [
        {title:'商品名0', price: 10},
        {title:'商品名1', price: 11},
        {title:'商品名2', price: 12},
        {title:'商品名3', price: 13},
      ]
    }
  }
  _renderItem=(data)=>{
    //注意：渲染列表项的参数不是数据对象，而是封装对象：{index: 0,  item: {title:'', price:''}}
    //console.log(data);
    return (
      <TouchableOpacity>
        <Text>商品在数组的编号：{data.index}</Text>
        <Text>商品名称：{data.item.title}</Text>
        <Text>商品价格：{data.item.price}</Text>
        {/* <View style={{height:1, backgroundColor:'#555'}}></View> */}
      </TouchableOpacity>
    )
  } 
  _createSepartor(){
    return (
      <View style={{height:1, backgroundColor:'#555'}}></View>
    )
  }
  render(){
    return (
      <View>
        <FlatList data={this.state.plist}  renderItem={this._renderItem} ItemSeparatorComponent={this._createSepartor}>
        </FlatList>
      </View>
    )
  }
}
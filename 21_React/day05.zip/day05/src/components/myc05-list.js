import React from 'react'
import {View, Text, FlatList, TouchableOpacity, Image} from 'react-native'

export default class MyC05 extends React.Component{
  //静态属性：则整个类型只需存储一份，访问使用MyC05.url
  static url = 'http://www.codeboy.com/data/product/list.php?pno='
  static serverUrl = 'http://www.codeboy.com/'

  //实例属性：每个当前类的实例都有一份
  pno = 0

  constructor(){
    super()
    this.state = {
      plist: []
    }
  }

  //组件挂载到页面中,就异步请求服务器端数据
  componentDidMount(){
    this.pno = 1
    fetch(MyC05.url).then( (res)=>{
        return  res.json()
    } ).then( (result)=>{
        //console.log(result)
        this.setState({
          plist: result.data  
          //[{lid:10,title:'',price:'', pic:''}]
        })
    } )
  }
  _renderItem = (data)=>{
    //data: {index: 0, item: {lid:10,title:''}}
    return (
      <View style={{marginBottom:20}}>
        <Image source={{uri: MyC05.serverUrl + data.item.pic}} style={{width:80,height:80}}/>
        <Text>标题：{data.item.title}</Text>
        <Text>价格：{data.item.price}</Text>
      </View>
    )
  }
  _onEndReached = ()=>{
    this.pno++;
    fetch( MyC05.url + this.pno).then( (res)=>{
      return res.json()
    } ).then( (result)=>{
      //把新获得的数据放到原有数据尾部
      let plist = this.state.plist;
      plist = plist.concat(result.data)
      this.setState({  plist })
    } )
  }
  render(){  
    return (
      <View>
        <FlatList data={this.state.plist} renderItem={this._renderItem} onEndReachedThreshold={0.1} onEndReached={this._onEndReached}>
        </FlatList>
      </View>
    )
  }
}


/*
class Student {
  sname='未命名'  
}
let  s1 = new Student();
s1.sname = 'dingding';
let  s2 = new Student();
s2.sname = 'yaya';

console.log(s2.sname);
console.log(s2.sname);
*/




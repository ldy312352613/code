import React from 'react'
import {View, StyleSheet, Image, Text, TouchableOpacity} from 'react-native'

let ss = StyleSheet.create({
  box: {
    flexDirection: 'column'
  },
  row: {
    flexDirection: 'row'
  },
  col: {
    flex: 1,
    padding: 30,
    flexDirection: 'column',
    alignItems: 'center'
  },
  txtCenter: {
    textAlign: 'center'
  }
})

export default class MyC08 extends React.Component{
  render(){          
    return (
      <View style={ss.box}>
        <View style={ss.row}>
            <View style={ss.col}>
              <TouchableOpacity>
                <Image source={require('../assets/menu_product.jpg')}/>
                <Text style={ss.txtCenter}>商品管理</Text>
              </TouchableOpacity>  
            </View>
            <View style={ss.col}>
              <TouchableOpacity>
                <Image source={require('../assets/menu_user.jpg')}/>
                <Text style={ss.txtCenter}>用户管理</Text>
              </TouchableOpacity>  
            </View>
        </View>
        <View style={ss.row}>
            <View style={ss.col}>
              <TouchableOpacity>
                <Image source={require('../assets/menu_order.jpg')}/>
                <Text style={ss.txtCenter}>订单管理</Text>
              </TouchableOpacity>  
            </View>
            <View style={ss.col}>
              <TouchableOpacity>
                <Image source={require('../assets/menu_refresh.jpg')}/>
                <Text style={ss.txtCenter}>首页内容管理</Text>
              </TouchableOpacity>  
            </View>
        </View>
      </View>
    )
  }
}



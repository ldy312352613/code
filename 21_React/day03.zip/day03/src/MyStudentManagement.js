import React from 'react'
import MyStudentAdd from './MyStudentAdd';
import MyStudentList from './MyStudentList';

export default class MyStudentManagement extends React.Component {
  constructor(){
    super()
    //固定this的指向
    this.doDeleteStu = this.doDeleteStu.bind(this)
    this.doSaveStu = this.doSaveStu.bind(this)
    //学生列表数据，既要在“学生添加”组件使用，也要在“学生列表”组件使用——应该设计在公共父组件中
    this.state = {
      stuList: [
        {sname: '丁丁', sex:'男', age: 20, home: '上海'},
        {sname: '当当', sex:'女', age: 19, home: '重庆'},
        {sname: '豆豆', sex:'男', age: 21, home: '天津'},
      ]
    }
  }
  doDeleteStu(index){
    //根据下标删除学生——参数是子组件提供的
    console.log('PARENT: ', index)
    let list = this.state.stuList
    list.splice(index, 1)
    this.setState({   //修改后的状态数据重新保存回状态数据中
      stuList: list
    })
  }
  doSaveStu(stu){
    //接收子组件提供的新学生信息，保存入学生列表
    let stuList = this.state.stuList
    stuList.push(stu)
    this.setState({ stuList })
  }
  render(){
    return (
      <div>
        <h1>学生管理系统</h1>
        <hr />
        <MyStudentAdd saveStu={this.doSaveStu}/>
        <MyStudentList list={this.state.stuList}  deleteStu={this.doDeleteStu} />
      </div>
    )
  }
}
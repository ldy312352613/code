import React from 'react'

export default class MyStudentAdd extends React.Component{
  constructor(){
    super()
    this.doSnameChange = this.doSnameChange.bind(this)
    this.doAgeChange = this.doAgeChange.bind(this)
    this.doSexChange = this.doSexChange.bind(this)
    this.doSave = this.doSave.bind(this)
    //当前组件内部的未最终提交给父组件的状态数据
    this.state = {
      sname: '',
      sex: '女',
      age: '',
      home: '杭州'
    }
  }
  doSnameChange(e){
    let inputValue = e.target.value;
    inputValue = inputValue.toUpperCase();
    //经过转换/筛选，输入已经是合法的了，可以保存到状态
    this.setState({
      sname: inputValue
    })
  }
  doAgeChange(e){
    let age = e.target.value  //用户输入的原始数据
    age = parseInt(age)       //对用户输入进行加工/检查
    age = isNaN(age) ? '' : age
    this.setState({           //加工后的数据保存到状态
      age: age
    })
  }
  // doHomeChange(e){
  //   let home = e.target.value
  //   this.setState({  home })
  // }
  doSexChange(e){
    //注意：onChange事件对于radio只有被选中的才会触发
    //取消选中的元素不会触发onChange
    let sex = e.target.value;
    this.setState({  sex  })
  }
  doSave(){
    //把输入好数据传递给父组件，保存到学生列表
    this.props.saveStu(this.state)
    //把输入框内容清空
    this.setState({
      sname: '',
      sex: '女',
      age: '',
      home: '杭州'
    })
  }
  render(){
    return (
      <div>
        <h3>添加学生</h3>
        <label htmlFor="sname">姓名：</label>
        <input id="sname" value={this.state.sname} onChange={this.doSnameChange}/>
        <br/>

        <label>性别：</label>
        <input type="radio" name="sex" value="男" checked={this.state.sex==='男'} onChange={this.doSexChange}/>男
        <input type="radio" name="sex" value="女" checked={this.state.sex==='女'} onChange={this.doSexChange}/>女
        <br/>
        
        <label htmlFor="age">年龄：</label>
        <input id="age" value={this.state.age} onChange={this.doAgeChange}/>
        <br/>
        
        <label htmlFor="home">籍贯：</label>
        <select id="home" value={this.state.home} onChange={(e)=>this.setState({home:e.target.value})}>
          <option value="北京">北京</option>
          <option value="上海">上海</option>
          <option value="杭州">杭州</option>
          <option value="成都">成都</option>
          <option value="深圳">深圳</option>
        </select>
        <br/>
        <button onClick={this.doSave}>保存</button>
      </div>
    )
  }
}
import React from 'react'

export default class MyButton extends React.Component{
  constructor(){
    super()
    console.log('MyButton.constructor')
  }
  //即将加载
  componentWillMount(){
    console.log('MyButton.componentWillMount')
  }
  //挂载完成
  componentDidMount(){
    console.log('MyButton.componentDidMount')
  }
  //即将卸载
  componentWillUnmount(){
    console.log('MyButton.componentWillUnMount')
  }
  //渲染
  render(){
    console.log('MyButton.render')
    return (      <button>按钮</button>    )
  }
}
import React from 'react'

export default class MyProductList extends React.Component{
  //不是所有数据都必须放到state中！
  //如果数据无需绑定/呈现，就不必放到state中
  url = 'http://www.codeboy.com/data/product/list.php?pno=';
  pno = 0; //要加载的分页页号
  
  constructor(){
    super()
    this.loadMore = this.loadMore.bind(this)
    this.state = {
      productList: []
    }
  }
  componentDidMount(){
    //组件加载完成后，异步请求第一页产品数据
    fetch(this.url).then((res)=>{
      return res.json()
    }).then((data)=>{
      let list = data.data; //当前加载的商品数据
      this.pno = data.pno; //当前加载的页号
      this.setState({ //把请求得到的数据保存入状态
        productList: list
      })
    })
  }
  loadMore(){
    this.pno++;  //加载下一页
    fetch(this.url+this.pno).then((res)=>{
      return res.json()
    }).then( (data)=>{
      let list = this.state.productList;
      list = list.concat( data.data )
      //保存回状态对象，再次触发render
      this.setState({
        productList: list
      })
    })
  }
  render(){
    return (
      <div>
        <h2>商品列表</h2>
        <ul>
          {
            this.state.productList.map((p, i)=>{
              return (
                <li key={i}>
                  {p.title}
                </li>
              )
            })
          }
        </ul>
        <button onClick={this.loadMore}>加载更多</button>
      </div>
    )
  }
}
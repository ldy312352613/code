//接收UI线程传递数据
onmessage = function(e){
var end = parseInt(e.data);
   //1:创建开始时间
var start = new Date().getTime();
//2:创建循环，创建结束时间
do{
//3:判断条件:如果结束时间-开始时间
var end1 = new Date().getTime();
//  继续循环
}while(end1-start<end);
postMessage("执行完毕");
}

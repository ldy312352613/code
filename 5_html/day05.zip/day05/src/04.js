//1:接收UI传递数值
onmessage = function(e){
 //2:计算累加和
 var n = e.data;
 //累加和
 var sum = 0;
 for(var i=1;i<=n;i++){
   sum+=i;
 }
 //3:将结果发送04.html
 postMessage(sum);
}
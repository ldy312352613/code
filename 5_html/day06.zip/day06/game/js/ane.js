//ane.js 海葵文件
//1:创建海葵构造函数 aneObj
var aneObj = function(){
   this.x = []; //保存海葵x坐标
   this.len = [];//保存海葵高度
}
//2:为构造函数原型添加属性num=50
aneObj.prototype.num = 50;
//3:为构造函数原型添加方法init
aneObj.prototype.init = function(){
//为海葵x与高度赋值  
  for(var i=0;i<this.num;i++){
this.x[i]=i*16+Math.random()*20;
this.len[i]=200+Math.random()*50;
  }
}
//17:55 
1：调错
2: 圆角 宽度  颜色
   ctx.globalAlpha = 0.5;
//4:为构造函数原型添加方法draw
aneObj.prototype.draw = function(){
  //4.1:保存状态
  ctx2.save();
  for(var i=0;i<this.num;i++){
    //开始一条新路径
    ctx2.beginPath();
    //将画笔移动到画布底端
    ctx2.moveTo(this.x[i],canHeight);
    //向上画一条直线
    ctx2.lineTo(this.x[i],canHeight-this.len[i]);
    //描边
    ctx2.stroke();
  }
  //4.7:恢复状态
  ctx2.restore();
}
//5:将ane.js文件添加index.html
//6:在main.js 创建对象并且调用
//  相关方法
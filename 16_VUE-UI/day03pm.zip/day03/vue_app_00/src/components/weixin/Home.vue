<template>
  <div class="weixin_container">
     <!--Home.vue-->
     <!--1:顶部标题栏子组件-->
     <titlebar
      leftTitle="微信(11)"
      :rightFirstImg="require('../../assets/ic_search.png')"
      :rightSecondImg="require('../../assets/ic_add.png')"
      :search="mysearch"
      :add3="myadd3" 
     ></titlebar>
    <!--2:防止顶部内溢出-->
    <!--3:面板 1父面板 4子面板-->
    <!--4:底部导航条-->
  </div>  
</template>
<script>
//1:导入顶部导航条子组件
import TitleBar from "./common/TitleBar.vue"
//3:调用顶部导航条子组件
export default {
     data(){
       return {}
     },//2:注册顶部导航条子组件
     methods:{
       mysearch(){
         console.log("搜索")
         },
       myadd3(){
         console.log("添加")
       }
     },
     components:{
       "titlebar":TitleBar
     }
}  
</script>
<style>
</style>
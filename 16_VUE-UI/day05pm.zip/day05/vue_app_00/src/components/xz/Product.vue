<template>
   <div>
     Product.vue
   </div>  
</template>
<script>
  export default {
    data(){
      return {
        list:[]
      }
    },
    methods:{
      loadMore(){//加载更多的数据
        var url = "product";
        this.axios.get(url).then(result=>{
          //17:52
          console.log(result.data.data);
          this.list = result.data.data
        })
      }
    },
    created() {
       this.loadMore();
    },
  }  
</script>
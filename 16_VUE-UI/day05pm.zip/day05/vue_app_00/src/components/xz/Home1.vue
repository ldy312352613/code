<template>
   <div>
     学子商城 /Home1组件
   </div>  
</template>
<script>
 export default {
   data(){
     return {}
   }
 }  
</script>
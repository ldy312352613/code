//router.js 引入路由
import Vue from 'vue'
import Router from 'vue-router'
//自定义组件
import HelloContainer from "./components/HelloWorld.vue"
//1:引入Exam01.vue 组件 39
import Exam01 from "./components/exam/Exam01.vue"
import Exam02 from
"./components/exam/Exam02.vue"
import Exam03 from "./components/exam/Exam03.vue"
Vue.use(Router)
export default new Router({
  routes: [
    {path:'/Exam03',component:Exam03},
    {path:'/Exam02',component:Exam02},
    {path:'/',component:HelloContainer},
    {path:'/Exam01',component:Exam01}
  ]
})

#可变长度的参数
#Python默认不允许多个函数名一样；否则后面的后覆盖前面的
"""
def add(n1, n2):
  sum = n1 + n2
  return sum

def add(n1, n2, n3):
  sum = n1 + n2 + n3
  return sum

result = add(10, 20, 30)
print(result)
result = add(100, 200)
print(result)
"""
def add(*args):
  print('add 方法内部：')
  #print(args)
  sum = 0
  for n in args:
    sum += n
  return sum

result = add()
print(result)

result = add(10)
print(result)

result = add(10,20)
print(result)

result = add(10,20,30)
print(result)



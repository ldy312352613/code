#非面向对象编程中，离散的变量无法表示完整的对象
#ename = 'Tom'
#salary = 5000
#isMarried = True

#OOP：封装，把相关数据整合为一个整体
class Emp :
  #在构造方法中为类型声明属性成员——第一个形参必须是指向自己的变量
  def __init__(self, n, s, m) :
    print('一个Emp实例被创建了')
    self.ename = n    #声明一个属性成员
    self.salary = s    #声明一个属性成员
    self.isMarried = m   #声明一个属性成员

  #对象内部的方法成员
  def printInfo(self) :
    print('员工姓名：%s 工资：%f 婚否：%d'%(self.ename, self.salary, self.isMarried))

#根据类型创建出实例——对象实例化
e1 = Emp('丁丁',5000,True)#调用构造方法创建一个实例
e1.printInfo()

e2 = Emp('丫丫',8000,False)#调用构造方法创建一个实例
e2.printInfo()

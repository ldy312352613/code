#TypeScript中属性/方法的访问修饰符：private/public/proteded

#类中的特殊属性：私有/公共属性

class Emp :
  def __init__(self, n, s, m) :
    self.__ename = n    #声明一个属性成员
    self.salary = s    #声明一个属性成员
    self.__isMarried = m   #声明一个属性成员

  #对象内部的方法成员
  def printInfo(self) :
    print('员工姓名：%s 工资：%f 婚否：%d'%(self.__ename, self.salary, self.__isMarried))

#根据类型创建出实例——对象实例化
e1 = Emp('丁丁',5000,True)#调用构造方法创建一个实例

e1.printInfo()
# print(e1.__ename)   #私有属性不能在类外面使用
print(e1.salary)
# print(e1.__isMarried)  #私有属性不能在类外面使用

#多态：一个方法，可以运行出多种效果
class Emp :
  def __init__(self, n, s) :
    print('一个Emp对象被构建了')
    self.ename = n   
    self.salary = s  

  #对象内部的方法成员
  def printInfo(self) :
    print('员工姓名：%s 工资：%f'%(self.ename, self.salary))

class Coder( Emp ):
  def __init__(self, ename, salary, lang):
    super().__init__(ename, salary) 
    self.language = lang 
    print('一个Coder对象被构建了')
  
  #子类继承了printInfo方法，但是觉得不够用，于是重写了/覆盖了父类的同名方法
  def printInfo(self):
    print('程序员姓名：%s 工资：%f 擅长的语言：%s'%(self.ename, self.salary, self.language))


#创建程序员对象
e1 = Emp('当当',8000)
e1.printInfo()

c1 = Coder('当当',8000,'JS/ES/TS')
c1.printInfo()

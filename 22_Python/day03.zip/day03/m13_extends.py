#继承： Coder is a Emp
#is a关系就是继承关系

class Emp :
  def __init__(self, n, s) :
    print('一个Emp对象被构建了')
    self.ename = n   
    self.salary = s  

  #对象内部的方法成员
  def printInfo(self) :
    print('员工姓名：%s 工资：%f'%(self.ename, self.salary))

class Coder( Emp ):
  def __init__(self, ename, salary, lang):
    super().__init__(ename, salary)  #子类构造方法内部第一句永远调用父类的构造方法
    self.language = lang    #子类专有的成员属性
    print('一个Coder对象被构建了')

#创建程序员对象
c1 = Coder('当当',8000,'JS/ES/TS')
print(c1.ename)
print(c1.salary)
print(c1.language)
c1.printInfo()

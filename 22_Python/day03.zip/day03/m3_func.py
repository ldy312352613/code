#关键字参数 —— 其它语言没有此特性
def connect(host, user, pwd, port ,db):
  print('开始连接数据库...')
  print('主机：%s 用户名：%s 密码：%s 端口号:%s 数据库名：%s'%(host, user, pwd, port, db))

#调用此函数
#connect('127.0.0.1', 'root', '123456', '3306', 'xz')
#connect('127.0.0.1','3306','root','xz', '123456')   #逻辑完全错误
connect(host='127.0.0.1',port='3306',user='root',db='xz', pwd='123456')  
#变量/函数的作用域

#局部作用域
""" 
def add():
  mySum = 100   #局部变量
  print(mySum)

add()
print(mySum)
"""

#全局作用域
"""
mySum = 200   

def add():
  #mySum = 20 #不是修改全局变量，是定义了一个新的局部变量
  global mySum   #声明此处的mySum是全局变量
  mySum = mySum+1
  print(mySum)

add()
print(mySum)
"""

#闭包作用域
def outer():
  mySum = 300
  def inner():
    print(mySum)
  return inner

f2 = outer()    #f2 = inner
f2()  #闭包 = 执行作用域对象+对外公开的函数

#print(mySum)

#sum = 30      #G：Global，全局作用域

def outer():
  sum = 20      #E：Enclosing，闭包作用域
  def inner():
    #sum = 10    #L：Local，局部作用域
    #global  sum    #声明使用全局变量
    nonlocal sum    #声明使用闭包作用域变量
    sum = sum + 1
    print('inner:', sum)    
  return inner

f = outer()     #f=inner
f()
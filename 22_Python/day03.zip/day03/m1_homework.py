#创建函数，输出九九乘法表
def print99():
  for i in range(1,10):
    for j in range(1,i+1):
      print('%d*%d=%d '%(i,j,i*j), end="")
    print()
#调用函数 
print99()

#创建函数：返回指定范围内所有闰年组成的列表
#myList = getLeapYears(start, end)
def getLeapYears(start, end):
  myList = []   #要放置闰年的列表
  for y in range(start, end):
    if (y%400==0) or ((y%4==0) and (y%100!=0)):
      myList.append(y)
  return myList

list2 = getLeapYears(2000, 2100)
print(list2)
#创建函数：返回指定范围内所有质数组成的列表
#myList = getPrimes(start, end)
def getPrimes(start, end):
  myList = []  #要放置质数的列表
  for n in range(start, end):
    #判断数字n是否为质数
    for i in range(2, n):  #从2~n-1依次去除n
      if n%i==0:
        break
    #整除循环执行完查看i的值处于什么范围
    if i>=n-1:  #i>=n-1说明上述循环没执行过break
      myList.append(n)
  return myList
#调用函数
list3 = getPrimes(10,100)
print(list3)

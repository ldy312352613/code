def  setAge( age ):
  if age>=18 and age<60:
    print('年龄合法！正在保存：', age)
  else:
    #print('年龄非法！无法保存！')
    #要求：年龄非法，则不再执行本函数的任何内容，要求调用者必须处理
    raise Exception('年龄非法！无法保存！')
  print('----setAge即将推出----')


try:
  #setAge(20)
  setAge(2)
except  Exception as err:
  print(err)

print('====程序结束====')
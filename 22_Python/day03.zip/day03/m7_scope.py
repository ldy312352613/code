
#sum = 30         #G：Global，全局作用域

def outer():
  #sum = 20       #E：Enclosing，闭包作用域
  def inner():
    #sum = 10     #L：Local，局部作用域
    print('inner:', sum)    #如果本地、闭包、全局作用域都没有sum，则默认使用内置作用域提供的sum
  return inner

#inner()
#print(sum)
f = outer()     #f=inner
f()
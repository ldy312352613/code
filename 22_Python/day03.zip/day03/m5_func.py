#可变长度的参数
#Python默认不允许多个函数名一样；否则后面的后覆盖前面的
def add(**args):
  print('add 方法内部：')
  print(args)
  # sum = 0;
  # for i in args:
  #   sum += args[i]
  # return sum

add()
# add(10)  #TypeError
add(n1=10, n2=20, n3=30)
add(n1=10, n2=20, n3=30, n4=40, n5=50)

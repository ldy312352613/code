#练习：封装、继承、多态
'''
练习：画图板程序中需要使用一个类型：Shape(形状)，其中有属性background（表示背景颜色）、foreground（前景颜色）、borderWidth（边框宽度）；并提供一个打印对象信息的方法：printInfo()试着定义该类，并创建该类的两个实例
练习：画图板程序中还需要一个类型：Rectangle(矩形)，其中除了有Shape所具有的全部特征外，还有width和height属性；定义出该类，并创建该类的两个实例
'''
#图形类
class Shape:
  def __init__(self, background,foreground,borderWidth):
    self.background = background
    self.foreground = foreground
    self.borderWidth = borderWidth
  
  def printInfo(self):
    print('图形的背景色：%s 前景色：%s 边框宽度：%d'%(self.background, self.foreground, self.borderWidth))

#矩形类
class Rectangle( Shape ):
  def __init__(self,background,foreground,borderWidth,width,height):
    super().__init__(background,foreground,borderWidth)
    self.width = width
    self.height = height

  def printInfo(self):
    print('矩形的背景色：%s 前景色：%s 边框宽度：%d 宽度：%d 高度：%d'%(self.background, self.foreground, self.borderWidth, self.width, self.height))

#构建一个图形对象实例       
s1 = Shape('red', 'blue', 10)
s1.printInfo()
#构建一个矩形对象实例
r1 = Rectangle('gray', 'black',20, 800,500)
r1.printInfo()
#异常处理
#让用户输入两个数字，程序输出它们的商
try:
  n1 = input('请输入被除数：')
  n1 = int(n1)    #可能抛出ValueError
  n2 = input('请输入除数：')
  n2 = int(n2)    #可能抛出ValueError
  result = n1/n2  #可能抛出ZeroDivisionError
  print('%d和%d的商为：%f'%(n1,n2,result))
except ValueError as err:
  #print('您输入了非法的数字')
  print(err)
except ZeroDivisionError as err:
  #print('您输入的除数不能为0')
  print(err)
finally:
  print('----即将离开可能发生异常的代码块----')

print('====程序运行结束====')

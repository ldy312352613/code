#带默认值的参数
def  add( num1=10,  num2 ):
   sum = num1 + num2
   return  sum

# result = add(10, 20)
# result = add(20)  #TypeError
# result = add(10, 20, 30)  #TypeError

# result = add(100, 200)
# result = add(100)
result = add(50)
print(result)
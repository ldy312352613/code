#类中的特殊属性：类属性

class Emp :
  addr = '北京市'   #类属性
  def __init__(self, n, s, m) :
    self.ename = n    #声明一个属性成员
    self.salary = s    #声明一个属性成员
    self.isMarried = m   #声明一个属性成员

  #对象内部的方法成员
  def printInfo(self) :
    print('员工姓名：%s 工资：%f 婚否：%d 住址：%s'%(self.ename, self.salary, self.isMarried, self.addr))

#根据类型创建出实例——对象实例化
e1 = Emp('丁丁',5000,True)#调用构造方法创建一个实例
Emp.addr = '上海市'

e1.printInfo()
print(e1.ename)
print(e1.salary)
print(e1.isMarried)
print(e1.addr)
print()
#print( Emp.ename )   #不能使用类名访问实例属性
print( Emp.addr )

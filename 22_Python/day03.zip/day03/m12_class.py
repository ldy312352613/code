'''
练习：画图板程序中需要使用一个类型：Shape(形状)，其中有属性background（表示背景颜色）、foreground（前景颜色）、borderWidth（边框宽度）；并提供一个打印对象信息的方法：printInfo()试着定义该类，并创建该类的两个实例
'''
class Shape :
  def __init__(self, b, f, w) :
    self.__background = b   #私有的成员属性
    self.__foreground = f
    self.__borderWidth = w
  
  def printInfo(self) : #同一个类内部访问自己的私有成员
    print('图形的背景色：%s 前景色：%s 边框宽度：%d'%(self.__background, self.__foreground, self.__borderWidth))

#对象实例化
s1 = Shape('red', 'green', 10)
#print(s1.__background)   #AttributeError 
s1.printInfo()

s2 = Shape('pink', 'blue', 20)
s2.printInfo()
print('main模块开始运行了')

#导入包中的模块
#错误：import不能导入包   import controller

#正确 import controller.user
#print('main: ', controller.user.uname)

import controller.user as cu
print('main: ', cu.uname)
cu.login()

import controller.product as cp
print('main:', cp.uname)
print('main3开始运行了')

import controller.user
import controller.user
import controller.user
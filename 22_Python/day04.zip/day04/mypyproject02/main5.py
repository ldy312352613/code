print('main5开始执行了')


#受__all__影响：from controller import  *
#不受__all__影响：from controller import user,product
import controller.user
import controller.product

print('main5: ', controller.user.uname)
print('main5: ', controller.product.uname)
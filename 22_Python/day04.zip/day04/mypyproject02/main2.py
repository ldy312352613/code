print('main模块开始运行了')

#导入包中的模块
'''
from controller.user import uname, login

print('main: ', uname)
login()
'''

from controller  import user,product

print('main:', user.uname)
user.login()
print('main:', product.uname)
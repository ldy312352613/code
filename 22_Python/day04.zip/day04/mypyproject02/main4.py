print('main4开始运行了')

#from controller import user,product
from controller import *   #__all__

print('main:', user.uname)
print('main:', product.uname)
print('controller包下的user模块开始运行了')

uname = 'dangdang-user'

def login():
  print('user.login....', uname)

#__name__：指代当前模块在运行时由解释器赋予的模块名：①若当前模块是启动模块，则此值为'__main__'  ②若当前模块被其它默认导入，则此值为'controller.user'
#print('user.py: ', __name__)
if __name__ == '__main__' :
  #此模块当前是启动模块——用户在测试此模块
  print('开发者在测试user模块')
  login()
#else: 此模块当前不是启动模块，是在被导入
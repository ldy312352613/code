
#__init__.py是一个包的初始化文件
print('package controller即将被调用')

#声明当前包下有哪些模块可被外界导入
#只对外部的import  * 导入有影响
#__all__=['user', 'product']
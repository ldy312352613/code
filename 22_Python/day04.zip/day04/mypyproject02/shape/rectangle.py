#矩形的宽
width = 20
#矩形的高
height = 10

#计算矩形的面积
def getSize():
  return width * height

#计算矩形的周长
def getPerimeter():
  return 2 * (width + height)


#矩形模块的单元测试
if __name__ == '__main__':
  print('矩形模块单元测试开始')
  print( getSize() )
  print( getPerimeter() )
  print('矩形模块单元测试结束')
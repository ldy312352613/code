#圆形的半径
r = 10

#计算圆形的面积
def getSize():
  return 3.14 * r * r

#计算圆形的周长
def getPerimeter():
  return 2 * 3.14 * r

#当前模块的单元测试
if __name__=='__main__':
  print('圆形的单元测试开始')
  print( getSize() )
  print( getPerimeter() )
  print('圆形的单元测试结束')


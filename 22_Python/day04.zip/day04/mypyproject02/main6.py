print('main6开始执行')

#import shape.circle as c
#import shape.rectangle as r
from shape import circle as c
from shape import rectangle as r

print('圆形的面积：', c.getSize())
print('圆形的周长：', c.getPerimeter())
print('矩形的面积：', r.getSize())
print('矩形的周长：', r.getPerimeter())
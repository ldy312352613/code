#使用第三方模块连接MySQL数据库
import  mysql.connector

#连接到MySQL服务器
conn = mysql.connector.connect(host='127.0.0.1', port=3306, user='root', password='', database='xz')

#向MySQL服务器发送SQL语句
print(conn)

#关闭数据库连接
conn.close()
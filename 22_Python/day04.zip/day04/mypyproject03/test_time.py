#测试time模块
import time as t

#print('测试开始...')
#time.sleep(3)
#print('测试结束...')

#获取当前系统时间（以秒为单位）  new Date().getTime()
print( t.time() )
print( int( t.time()*1000 ) )   #当前系统时间：以毫秒为单位

#把当前系统时间转换为年月日时分秒格式  new Date().getFullYears()....
sec = t.time()   #时间数值sec = 0
lt = t.localtime(sec)   #把数值转换为“本地时间”对象
str = t.strftime('%Y-%m-%d %H:%M:%S')  #把“本地时间”对象转换为特定格式的字符串
print(str)
print( t.strftime('%Y-%m-%d', t.localtime(t.time()))  )

#把年月日时分秒字符串转换为整数
lt = t.strptime('1970-1-1 8:0:0', '%Y-%m-%d %H:%M:%S')  #把字符串解析为“本地时间”对象
sec = t.mktime(lt) #把“本地时间”对象转换为数字
print( sec )
import json
data = [ 
  {'uid':101, 'uname':'dingding', 'age':20}, 
  {'uid':102, 'uname':'dangdang', 'age':21}, 
  {'uid':103, 'uname':'doudou', 'age':22}, 
  {'uid':104, 'uname':'yaya', 'age':23}, 
]
#把Python对象转换为JSON字符串  JSON.stringify()
print(type(data))
print(data)
print()

str = json.dumps(data)  #重要：对象序列化：对象=>字符串
print(type(str))
print(str)
print()

#把JSON字符串解析为Python对象   JSON.parse()
obj = json.loads( str )   #重要：JSON字符串反序列化：字符串=>对象
print(type(obj))
print(obj)
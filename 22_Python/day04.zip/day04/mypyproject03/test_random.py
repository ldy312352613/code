#测试系统提供的random模块

import  random as r

#生成0~100间的随机整数
print( r.randrange(100) )

#生成四位的随机整数
print( r.randrange(1000, 10000) )

#生成100以内的随机整10的数
print( r.randrange(0, 100, 10) )

#随机抽取一个学员
stuList = ['1亮亮','2然然','3东东','4涛涛']
print( r.choice(stuList) )

#随机打乱序列中元素的位置——打乱数组中原有的数据
print( stuList )
r.shuffle(stuList)   #返回None
print( stuList )
#测试官方提供的模块：math
import math

print( math.ceil(3.5) )
print( math.floor(3.5) )
print( math.sin(  math.pi/6  ) )
print( math.pi )

#把相对路径转换为绝对路径
import os.path

p = os.path.abspath('./')
print( p )
p = os.path.abspath('../../')
print( p )
print('main模块开始运行了')

#引入其它模块对象
import user     #把模块作为一个完整的对象全部导入
import product as p

'''
print('main: ', user.uname)
# print('main: ', product.uname)
print('main: ', p.uname)
user.login()
'''
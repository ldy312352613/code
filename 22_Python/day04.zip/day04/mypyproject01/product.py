print('product模块开始运行了')

uname = 'yaya-product'
print('user模块开始运行')


uname = 'dangdang-user'

def login():
  print('user.login....', uname)
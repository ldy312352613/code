print('main模块开始运行了')

#引入其它模块对象
#错误： import uname from 'user'
#错误: from 'user' import uname 

#正确：from user import uname 
#正确：from user import login

from product import uname as pn 
from user import uname as un,login

#正确但谨慎使用： from user import *

# print('main:', uname)
print('main:', pn)
print('main:', un)
login()
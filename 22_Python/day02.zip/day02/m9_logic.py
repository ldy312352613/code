'''
#逻辑运算
age = 80
#该年龄是否为“工作年龄”
#print( age>=18 && age<60 )  错误
print( age>=18 and age<60 )
'''
#练习：从键盘读取一个年份数字输入，判断该年份是否是闰年
year = input('请输入一个年份：')
year = int(year) #str转换为int操作
#闰年公式：①可被400整除 ②可被4整除不能被100整除
print(  (year%400==0) or ((year%4==0) and (year%100!=0))  )
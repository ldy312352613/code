#不可变数据类型
s1 = 'abc'
print(s1)
print( id(s1) )

s2 = 'abc'
print(s2)
print( id(s2) )

s1 = 'xyz'
print(s1)
print( id(s1) )


print()

n1 = 100
print(n1)
print( id(n1) )

n2 = 100
print(n2)
print( id(n2) )

n1 = 200
print(n1)
print( id(n1) )
#集合
myList = ['张三', '李四', '王五', '张三','王五']
print(myList)

#把列表转换为集合
mySet = set( myList )
print(mySet)
print(type(mySet))

#创建集合
mySet2 = {100, 200, 300, 200, 100, 5, 9}

#添加元素
#mySet2.append(8) #错误
mySet2.add(8)  #添加一个不存在的元素
mySet2.add(9)  #已经存在的元素再次添加无效果

#删除元素
#del mySet2(0)  #错误
mySet2.remove(100)  #删除时不用下标，而用元素值

#访问第i个 —— 不可能实现：集合中的元素没有下标
#print(mySet[0])

print( mySet2 )

for n in mySet2:
  print(n)
  print('------')
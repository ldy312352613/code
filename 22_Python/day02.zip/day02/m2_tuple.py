#元组
myTuple = (100, 200, 300, 400)

#元组转换为列表
#myArr = list( myTuple )
#列表转换为元组
#myArr = tuple( myArr )

#print( type(myArr) )
#print( myArr )

#访问元素
print( myTuple[1] )
print( myTuple[1:3] )
#myTuple[1] = 210  错误
#myTuple.append(500)  错误
#myTuple.pop()

myArr = myTuple + myTuple
print( myTuple )
print( myArr )
#最简单的函数：没有形参、没返回值
"""
def sum() :
  num1 = 10
  num2 = 20
  num3 = num1 + num2
  print('和为：', num3)
#调用函数
sum()
"""
#有形参的函数
"""
def sum(num1, num2):
  num3 = num1 + num2
  print('和为：', num3)
#调用函数
#sum(100, 200, 300)   #TypeError！
#sum(100)   #TypeError
sum(100, 200)   #num1=100  num2=200
"""
#带返回值的函数
def sum(num1, num2):
  num3 = num1 + num2
  return num3   
  #如果没有声明return默认返回的是None

result = sum(1000, 2000)
print('1000和2000的算术和为：', result)
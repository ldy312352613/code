#in：成员运算符

myList = [5, 10, 7, 9]
n = 15

#JS判断n在列表中的下标：myList.indexOf(n)
print(  n  in  myList )
#print(  n  not  in  myList )
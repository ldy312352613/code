'''
练习：创建一个元组，其中包含若干正数、负数等数字，使用循环计算所有这些数字的和，并输出
'''
myTuple = (10, -5, 3, 80, 20, -30)
total = 0
'''
for n in myTuple:
  total += n
print('所有数字的总和为：', total)
'''

'''
i = 0   #元素下标
while i<len(myTuple) :
  total += myTuple[i]
  i += 1
print('所有数字的总和为：', total)
'''
'''
练习：创建一个元组，其中包含若干正数、负数等数字，使用循环计算所有这些数字的和(负数不要)——continue，并输出
'''
myTuple = (10, -5, 3, 80, 20, -30)
total = 0
'''
for  n  in myTuple :
  if n<0 :
    continue
  total += n
print('所有正数的和为：', total)
'''
i = 0  #元素下标
while  i<len(myTuple) :
  if myTuple[i]<0 :
    i += 1
    continue
  total += myTuple[i]
  i += 1
print('所有正数的和为：', total)
'''
练习：创建一个元组，其中包含若干正数、负数等数字，使用循环计算所有这些数字的和，一旦和超过100则立即停止不再添加——break，并输出此时的和
'''
myTuple = (80, -5, 3, 80, 20, -30)
total = 0
'''
for  n  in  myTuple :
  total += n
  if total>=100:
    break
print('刚刚超过100的总和为：', total)
'''
i = 0
while  i<len(myTuple) :
  total += myTuple[i]
  if total>=100 :
    break
  i += 1
print('刚刚超过100的总和为：', total)
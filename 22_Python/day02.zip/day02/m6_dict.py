'''
练习：创建一个商品对象（字典），让用户从键盘输入商品名称、单价、购买数量，最后输出：
	“商品名称：xxx 单价：xxx 购买数量： xxx 小计：xxx”
'''

product = {}

pname = input('请输入商品名称：')
product['pname'] = pname
#print(type(pname))  #str
#print(pname)

price = input('请输入商品单价：')
product['price'] = float(price)  #str转换为float

count = input('请输入购买数量：')
product['count'] = int(count)   #str转换为int

#print( type(product) )
#print( product )
print('商品名称：%s 单价：%.2f 购买数量：%d 小计：%.2f'%(product['pname'], product['price'], product['count'], product['price']*product['count']))
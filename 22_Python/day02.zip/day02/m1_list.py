#列表
myList = [100, 200, 300, 400]

#访问某个元素
myList[1] = 210
print( myList[1] )
print( myList[1:] )
print( myList[1:3] )

#添加新元素
myList.append(500)
myList.insert(0, 50)

#删除元素
del  myList[0]
myList.pop()
myList.pop(1)

#拼接列表
myList = myList + [800, 900]
myList = myList * 3

print( myList )
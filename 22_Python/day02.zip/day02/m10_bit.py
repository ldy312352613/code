#位运算
n1 = 10
n2 = 13

print( bin(n1) )  #把十进制数字转换为二进制形式
print( bin(n2) )

print( n1 & n2 )
print( n1 | n2 )
print( n1 ^ n2 )
print( ~n1 )

print()

a = 5
print( bin(5) )   #101
print( a << 1 )   #1010:  10=5*2^1
print( a << 2 )   #10100:  20=5*2^2
print( a << 3 )   #101000:  40=5*2^3
print( a << 4 )   #1010000:  80=5*2^4
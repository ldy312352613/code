#for..in..循环
#输出10个※号
for i in range(0,10) :
  print('※', end='')

print('\n循环结束')

#输出0/1/2/...9/数字序列
for  i  in   range(0, 10, 1) :
  print(i, end='')
  print('/', end='')
print('\n循环结束')

#遍历列表/元组/集合/字典
# myList = [10, 7, -5, 3, 8, -1]  #list
# myList = (10, 7, -5, 3, 8, -1)  #tuple
# myList = {10, 7, -5, 3, 8, -1}  #set
myList = {'chinese':10, 'math':7, 'english':-5}    #dict
for  n  in  myList :
  print('%s - %d'%(n, myList[n]))
print('\n列表遍历完成')
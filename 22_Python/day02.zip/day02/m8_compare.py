n1 = 1
n2 = True
n3 = 1.0

print( n1==n2 )   #隐式类型转换
print( n1==n3 )   #隐式类型转换

#print( n1===n2 )  #错误！
print( id(n1) == id(n2) )
print( n1  is  n2 )  #False
print( n1  is  not  n2 )  #True
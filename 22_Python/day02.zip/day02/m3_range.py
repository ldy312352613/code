#范围序列
myRange1 = range(10)
print(  myRange1  )
print(  list( myRange1 )  )

myRange2 = range(10, 20)
print( list(myRange2) )

myRange3 = range(10, 20, 2)
print( list(myRange3) )

myRange4 = range(100, 0, -10)
print( list(myRange4) )

'''
JS:  
for(let i=0; i<100; i++){console.log(i)}
'''
for tmp in range(10):
  print(tmp)
  print('------')


myList = [100,200,300,400,500]
for tmp in myList:
  print(tmp)
  print('======')

#思考：如何在一个循环中输出list中的每个元素及其下标？？
print()
print()

for i in range( len(myList) ):
  print('%d - %d'%(i, myList[i]))
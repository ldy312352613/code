#while循环
#输出10个※号
i = 0
while i<10 :
  print('※')
  #i++  #错误
  i += 1
print('\n循环结束')

#输出0/1/2/...9/数字序列
i = 0
while i<10 :
  print(i)
  print('/')
  i += 1
print('\n循环结束')

#遍历列表/元组 —— 不能使用while遍历集合/字典
# myList = [10, 7, -5, 3, 8, -1]  #list
myList = (10, 7, -5, 3, 8, -1)  #tuple
i = 0
while i<len(myList) :
  print('%d - %d'%(i, myList[i]))
  i += 1
print('\n列表遍历完成')
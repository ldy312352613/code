#成绩满80，则输出优秀；否则如果满60，输出及格，否则输出不及格
score = 7
"""
if score>=80 :
  print('优秀')
else :
  if score>=60 :
    print('及格')
  else :
    print('不及格')
"""
if score>=80:
  print('优秀')
elif score>=60:
  print('及格')
else:
  print('不及格')

print('程序结束')
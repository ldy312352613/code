"""
练习：数据库中使用一个数字表示订单的状态，如10-待付款、 20-发货中、 30-已完成、 其它-不可识别的订单状态；创建一个数字表示订单状态，根据其值输出对应的描述文字——使用两种方法实现
"""
stat = 50
"""
if 10==stat :
  print('待付款')
else :
  if 20==stat :
    print('运货中')
  else :
    if 30==stat :
      print('已完成')
    else:
      print('未知的订单状态')
"""
if 10==stat :
  print('代付款')
elif 20==stat :
  print('运货中')
elif 30==stat :
  print('已完成')
else :
  print('未知的订单状态')

print('程序结束')
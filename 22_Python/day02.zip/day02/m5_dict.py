#字典、映射对象
mySet = {'dingding', 20, True}
print( type(mySet) )
print( mySet )

#字典中元素的下标必须用引号，不能省略
myDict = {'uname':'dingding', 'age':20, 'isMarried':True}

#访问元素
print( myDict['uname'] )
#print( myDict['uname2'] )  #KeyError
#print( myDict.uname )   #错误！！
myDict['uname'] = 'dangdang'

#添加元素
myDict['salary'] = 6000 

#删除元素
del  myDict['age']

print( type(myDict) )
print( myDict )
'''
练习：让用户从命令行输入登录用户名，再输入登录密码，如果用户名为admin密码为123456，则输出“登录成功”否则输出“登录失败”
'''
uname = input('请输入登录名：')
upwd = input('请输入登录密码：')

if uname=='admin' and upwd=='123456':
  print('登录成功！')
  print('欢迎回来！')
else :
  print('登录失败！')
  print('请检查用户名和密码！')
print('程序结束')
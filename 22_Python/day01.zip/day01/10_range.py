#范围序列
myRange1 = range(100)
print(type(myRange1))
print(myRange1)   #range(0,10)

#myRange1 = range(50, 80)
#myRange1 = range(50, 80, 5)
myRange1 = range(10, 0, -2)

#把range强制转换为list，可以看到内部的元素
print( list(myRange1) ) 

#range通常与for..in组合应用
for n  in  range(0,100,1):
  print(n, end=" - ")

#上述循环模拟实现了其它语言中的普通for循环：for(let i=0; i<100; i++){ }



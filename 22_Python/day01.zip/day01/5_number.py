#整数具有无限精度
n1 = 78687678123461236487213648263428734
print(n1)
print(type(n1))

#bool是int的子集
n2 = True
n2 = n2 + 5
print(n2)
print(type(n2))

#浮点数
n3 = 9.0
print(n3)
print(type(n3))

n1 = 11
n2 = 4
#n3 = n1 + n2    #15
#n3 = n1 / n2    #2.75
#n3 = n1 % n2     #取余
#n3 = n1 // n2     #取商
n3 = n1 ** n2     #Math.pow(n1, n2)
print(n3)

#n1++   无效
#n1--   无效

n1 = n1 + 1
n1 += 1
print(n1)
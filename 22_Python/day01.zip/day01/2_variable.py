#创建变量
uname = 'dingding'
uname = "dangdang"

uname = 20

# uname = true
uname = True
uname = False

#输出变量
print(  type(uname) )
print(uname)
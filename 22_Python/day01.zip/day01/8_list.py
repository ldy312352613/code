myList1 = [10, 15, 18]
myList2 = [20, 23]

#数组拼接
myList3 = myList1 + myList2

#myList3 = myList1 + myList1 + myList1
myList3 = myList1 * 3
print(myList3)
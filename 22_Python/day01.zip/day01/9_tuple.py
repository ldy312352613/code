#元组
#myTuple = (100)     #int
#myTuple = [100, 200, 300]    #list

myTuple = (100,)     #tuple

print(type(myTuple))
print(len(myTuple))
print(myTuple)

#输出指定元素
print(myTuple[0])
#myTuple[0] = 150   错误！元组内容不可变！
#myTuple.append(500)  错误！

myTuple2 = myTuple  + myTuple
print(myTuple2)
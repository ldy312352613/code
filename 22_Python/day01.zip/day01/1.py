#print('hello')
"""
print("world")
print('helloworld')
print('hello','world')
"""

print(111, 222, 333)
#Print(111, 222, 333)
print(111, 222, 333, sep='/')

print( 888,  end=''  )    
print(999, end='')
txt = 'this is some content'
print( type(txt) )    #<class 'str'>

num = 123
num = str(num)        #强制类型转换
print( type(num) )

txt = "this is some content"

txt = '''this is 
some 
content'''

txt = """this is 
some 
content"""
print(txt)

txt = 'abcdefg'
#txt[0] = 'A'     错误！字符串都是不可变的
print( txt[0] )   #a
print( txt[0:4] ) #返回字符串的子串  abcd
print( txt[2:4] ) #返回字符串的子串  cd
print( txt[-1] )  #g
print( txt[-3:] ) #返回字符串的子串  efg
print( txt[:-3] ) #返回字符串的子串  abcd

print()
#使用for循环遍历字符串中的每个字符
for c in txt:
  print(c)
  print('------')
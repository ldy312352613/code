#list：内容可变的数组
myList = [100, 200, 300, 200]
print(myList)

#访问列表中内容
print( myList[0] )
print( myList[-1] )
print( myList[1:3] )  #取子数组
print( myList[1:] )
#print( myList[999] )  #IndexError错误！

#修改列表中的内容
myList[0] = 150  #修改已有元素

#列表中添加新元素
#myList[4] = 400  #错误！IndexError下标不能越界
#myList.push(400)  #错误！列表没有push方法
myList.append(400)  #列表尾部追加新元素
myList.insert(2, 500) #在任意位置追加新元素

#获取数组中元素的个数
print( len(myList) )

#删除列表中的元素
del myList[0] #删除开头的元素
del myList[ len(myList)-1 ]  #删除结尾的元素
#myList.pop()  #删除结尾的元素
#myList.pop(1)  #删除队列中央的元素
#print( myList )

#遍历列表
for  e  in  myList:
  print(e)
  print('-----')
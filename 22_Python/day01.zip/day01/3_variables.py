#创建三个变量，分别表示员工的姓名、年龄、是否已婚，最后一个print()中输出这三个变量的值
ename = '建国'
age = 20
isMarried = True

print('员工姓名为：'+ename) #字符串拼接
#print('员工年龄为：'+age)  #错误！+不会进行隐式类型转换
#print(ename + age + isMarried)  #错误

print('员工年龄为：' + str(age) )  #方式1
print('员工年龄为：', age, sep="" )  #方式2
print('员工姓名为：%s 年龄为：%d'%(ename,age))  #方式3

#练习：创建三个变量表示书籍的标题、书籍的销售数量、书籍的单价(35.5)，使用一个print输出这三个数据
bookTitle = '三国志'
price = 35.555
soldCount = 1000
print('书名：%s 单价：%.2f 销售数量：%d'%(bookTitle,price,soldCount))
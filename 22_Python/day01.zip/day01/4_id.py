#获取对象的标识
n1 = 100
n2 = 200
n3 = 100

print( type(n1) )
print( type(n2) )
print( type(n3) )

print( id(n1) )
print( id(n2) )
print( id(n3) )
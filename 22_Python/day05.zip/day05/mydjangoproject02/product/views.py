from django.http import HttpResponse
import json

#路由：/product/list?kw=macbook&pno=2
def productList(req):
  #print(json.dumps(req) )  #错误！不是每个对象都可以进行JSON序列化！
  k = req.GET['kw']
  p = req.GET['pno']

  res = HttpResponse('商品列表<hr>商品关键字：%s 页号：%s'%(k, p))
  return res

#路由：/product/detail/dell/25
#路由：/product/detail/lenovo/128
def productDetail(req, pname, pid):
  print('=====================================')
  print('待查询的厂家名称：',pname, type(pname))
  print('待查询的商品编号：',pid, type(pid))
  res = HttpResponse('商品详情<hr>')
  return res
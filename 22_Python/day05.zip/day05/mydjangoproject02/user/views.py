from django.http import HttpResponse, JsonResponse
import json

#路由：/user/login
def userLogin(req):
  # res = HttpResponse('用户登录<hr>')
  #Dict
  data = {'result': 'err', 'msg': 'uname or upwd err'}
  #JSONString
  data = json.dumps(data)

  #设置响应消息主体
  res = HttpResponse(data)
  #修改响应消息头部
  res['Content-Type'] = 'application/json'
  res['Access-Control-Allow-Origin'] = '*'
  return res

#路由：/user/register
def userRegister(req):
  #res = HttpResponse('注册新用户<hr>')
  data = {'result':'ok', 'msg':'register succ'}
  res = JsonResponse( data )  #省略了json.dumps
  #省略了res['Content-Type']='application/json'
  res['Access-Control-Allow-Origin']='*'
  return res

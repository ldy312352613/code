from django.http import HttpResponse

#路由处理方法(View)：news/list
def  newsList(req):
  res = HttpResponse('新闻列表<hr>')
  return res

#路由处理方法(View)：news/detail
def  newsDetail(req):
  res = HttpResponse('新闻详情<hr>')
  return res
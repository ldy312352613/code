"""mydjangoproject01 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.http import HttpResponse

#创建处理 / 请求的视图(View)(请求处理对象):
def index(req):
    res = HttpResponse('<h1>this is index<h1>')
    return res

#创建处理 /user/login 请求的视图(View)(请求处理对象):
def userLogin(req):
    res = HttpResponse('<h1>this is user/login..<h1>')
    return res



#整个项目的顶级路由词典
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', index),  #为路由处理方法分配路由地址
    # path('user/login', userLogin),  #为路由处理方法分配路由地址
    #path('/user/login', userLogin),  #错误
    #path('user/login/', userLogin),  #可以运行，但浏览器会自动拼接尾部/
]

// pages/db/db.js
//创建常量 db
//初始化默认云数据库
const db = wx.cloud.database();

Page({
  data: {
  },
  remove:function(){
    db.collection("web1903user")
      .doc("f1006ad85d2edd9509648ecb26e5ab23")
    .remove().then(res=>{
      console.log(res);
    }).catch(err=>{ 
      console.log(err);
    })
  },
  update3:function(){
    db.collection("web1903")
      .doc("8ee160f5-0c35-4a87-94c3-85d647113d61")
     .update({
       data:{
         age:70
       }
     }).then(res=>{
       console.log(res)
     }).catch(err=>{
       console.log(err);
     });
  },
  update:function(){
    //更新web1903user集合一条记录
    //doc 集合id[自动生成复制]
    //update 更新方法
    //car 更新项 凤凰 值
    db.collection("web1903user").
      doc("f1006ad85d2edd9509648ecb26e5ab23")
    .update({
      data:{
        car:"凤凰"
      }
    }).then(res=>{
      console.log(res);
    }).catch(err=>{
      console.log(err);
    });
  },
  insert:function(){
   //此方法完成向云数据web1903user
   //集合法加数据
   db.collection("web1903user").add({
     data:{
        uname:"亮哥",
        car:"杰安特"
     },
     success:(res)=>{
       console.log(res);
     },
     fail:(err)=>{
       console.log(err);
     }
   });

  },
  addData:function(){
    //此方法完成向云数据库web1903集合添加数据
    db.collection("web1903").add({
      data:{//添加记录
        name:"文华",age:60
      },
      success:(res)=>{//添加成功回调
        console.log(res)
      },
      fail:(err)=>{//添加失败回调
        console.log(err)
      }
    });
  },

  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
// pages/base/base.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    str1:"东哥有一家办证公司",
    num1:10.9,
    b3:true,
    d3:new Date(),
    list:[10,11,12,13],
    list3:[{no:9527,name:"李然"},
    {no:911,name:"东哥"}]
  },
  handle1:function(){
    console.log("子元素-支持冒泡传递");
  },
  handle2:function(){
    console.log("父元素-支持冒泡传递");
  },
  handle3:function(){
    console.log("子元素-不支持冒泡")
  },
  handle4:function(){
     console.log("父元素-不支持冒泡")
  },
  jumpAdmin:function(){
     //从base组件跳转admin组件并且
     //传递参数?id=19
     //wx.redirectTo(); 跳转
     //{url:组件地址}
     wx.redirectTo({
       url: '/pages/admin/admin?id=19',
     })
  },
  onLoad: function (options) {
    //Cannot read property 'getElementById' of undefine
    //var v3 = document.
    //getElementById("v3");

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   * base.js 
   * base -> admin
   * wx.redirectTo()
   * 先将base组件卸载->创建admin组件
   */
  onUnload: function () {
     console.log("5:当前组件己被卸载");
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
       console.log("用户下拉操作...")
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
       console.log("用户上拉操作....")
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
/*
// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init()
// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  return {
    event,
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
  }
}*/

//1:此函数功能:计算二个整型数和
//2:创建主函数
exports.main = async (event, context) => {
  //3:主函数内容完成求和操作
  //4:将计算结果返回
  return {
    sumd: event.i + event.j
  }
}
// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init();

//创建云函数删除云数据库多条记录
//web1903emp  name:kaka 所有记录
//1:初始化云数据库,并且数据库实例
const db = cloud.database();
//2:创建main函数
//async 异步执行 event 事件对象 参数
//context 上下文对象 用户信息
exports.main = async (event,context)=>{
   //捕获异常信息 e 异常对象
   //await 等待
   try{
     return await db.collection("web1903emp")
     .where({
       name:"kaka"//删除条件
     }).remove(); //删除数据
   }catch(e){
     console.log(e);
   }
}
//3:添加try{}catch 捕获异常错误
//4:返回  删除多条记忆录指令






/*
// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()

  return {
    event,
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
  }
}*/

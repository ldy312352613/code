// pages/cloud/cloud.js
Page({
  data: {
  },
  callBatch:function(){
    //删除指定数据 web1903emp
    wx.cloud.callFunction({
      name:"batchDelete04"//云函数名称
    })
    .then(res=>{          //删除成功回调
      console.log(123)
      console.log(res);   //结果
    })
    .catch(err=>{         //删除失败
      console.log(err);   //失败原因
    })
  },
  callLogin:function(){
    //上传成功
    wx.cloud.callFunction({
      name:"login10"   //云函数名称
    })
    .then(res=>{     //云函数调用成功
      console.log(res);//返回结果
    })
    .catch(err=>{    //云函数调用失败
      console.log(err);//失败原因
    })
  },


  callSuma:function(){
    //调用云函数
    wx.cloud.callFunction({
      name:"suma",    //suma云函数名字
      data:{i:9,j:12} //参数
    })
    .then(res=>{      //调用成功
      console.log(res);//计算结果
    })
    .catch(err=>{     //调用失败
      console.log(err);//失败原因
    })
  },
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
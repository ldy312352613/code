//1:创建数据库实例
const db = wx.cloud.database();
Page({
  data: {
     //list保存web1903emp所有记录
     list:[]
  },
  delItem:function(e){
    //函数功能:删除指定记录
    //1:获取删除此条记录条件 id
    //e 事件对象 target 触发事件对象
    //dataset 所有自定义属性对象
    var id = e.target.dataset.id;
    //2:依据id删除对应记录 58
    db
    .collection("web1903emp") //集合名称
    .doc(id)                  //删除条件id
    .remove()                 //删除
    .then(res=>{              //删除成功
      //console.log(res);
      this.loadMore();//重新加载最新数据
    })
    .catch(err=>{             //删除失败
      console.log(err);
    })
    //3:再新加载loadMore 显示最新结果

  },
  loadMore:function(){
    //1:负责查询云数据库中数据
    //2:并且将查询结果保存list
    //3:当组件创建成功立即调用此函数
    db.collection("web1903emp")  //集合名
    .get()                       //获取
    .then(res=>{                 //成功
      console.log(res.data);     //结果
      //将查询结果保存list数组中
      //调试器:appData
      this.setData({ 
        list:res.data 
      })
    })
    .catch(err=>{                //失败
      console.log(err)           //原因
    })
  },
  onLoad: function (options) {
    this.loadMore();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
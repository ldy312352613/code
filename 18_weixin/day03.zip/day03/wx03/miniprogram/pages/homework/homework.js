//1:初始化数据库
//db 数据库实例
//wx 小程序顶层对象
//cloud 云开发相关对象方法属性
//database({     获取数据库实例
//  env:"环境id"
//});
const db = wx.cloud.database();
Page({
  data: {
  },
  selectAll(){
    //查询web1903emp集合中所有数据 10:24
    db.collection("web1903emp")
    .get()
    .then(res=>{
      console.log(res);
    })
    .catch(err=>{
      console.log(err);
    })
  },
  selectWhere(){
     //查询name:kaka用户 指定数据
     db.collection("web1903emp")
     .where({
        name:"kaka"
     }).get()
     .then(res=>{
       console.log(res);
     })
     .catch(err=>{
       console.log(err);
     })
  },
  del(){
    db.collection("web1903emp")
      .doc("9afd9b6a5d2fcb5609d3bc8a256575d3")
      .remove()
      .then(res=>{
        console.log(res);//view 9:50
      })
      .catch(err=>{
        console.log(err);
      })
  },
  update(){
    //向web1903emp更新薪水
    db.collection("web1903emp")
      .doc("9afd9b6a5d2fcb5609d3bc8a256575d3")
    .update({
      data:{
        sal:3500
      }
    }).then(res=>{
      console.log(res);//9:38
    }).catch(err=>{
      console.log(err);
    });
  },
  //9:25 view 绑定tap调用insert
  insert(){
    db.collection("web1903emp")
    .add({
      data:{no:8,name:"kaka",sal:36000},
      success:res=>{
         console.log(res);
      },
      fail:err=>{
         console.log(err);
      }
    });
  },
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
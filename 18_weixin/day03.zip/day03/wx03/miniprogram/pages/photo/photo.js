// pages/photo/photo.js
Page({
  data: {
  },
  selectImage:function(){
    //选中用户指定图片 24
    //1:选择图片
    //2:指定选择几张图片
    //3:指定图片类型 原图 压缩
    //4:图片来源    相册  相机
    //5:成功选择图片后回调函数
     //5.1:获取选中图片地址
    wx.chooseImage({
      count:1,    //一次上传一张图片
      sizeType:["original","compressed"],
      sourceType:["album","camera"],
      success: function(res) {
        //选中图片地址列表 数组
        var list = res.tempFilePaths;
        //console.log(list); 17:49
        var file = list[0];
        wx.cloud.uploadFile({
          cloudPath: new Date().getTime() + ".jpg", filePath: file,
         success:res=>{
           console.log(res);
         } 
        })
        //上传图片至云存储
        //1:指定上传后新文件名
        //2:指定选中图片地址
        //3:上传成功回调函数
         //3.1:res.fileID 文件id



      },
    }) 
  },
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
//在"js"文件夹下新建"my-ui.js"
//内容如下: 
jQuery.fn.accordion=function(){
  //this->$("my-accordion")父元素
  var $parent=this;
  //1. 侵入class: 
  //给父元素自己添加.accordion
  $parent.addClass("accordion")
       //return $parent
  //父元素下奇数位置的直接子元素都加.title
    .children(":nth-child(2n+1)")
    .addClass("title")
    //return [.title,.title,.title]
  //每个title的下一个兄弟加.content和.fade
    .next()
    .addClass("content fade")
//return [.content,.content,.content]
  //所有.content中第一个再加.in
    .first()
    .addClass("in")
    //return 第一个.content
  //2. 添加行为: 
  $parent //事件委托
  .on("click",".title",function(){
    $(this).next(".content").toggleClass("in")
      .siblings(".content").removeClass("in")
  });
}
//$("my-accordion").accordion()
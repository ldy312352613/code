const http=require("http");
http.createServer((req,res)=>{
  res.writeHead(200,{
    "Access-Control-Allow-Origin":"http://127.0.0.1:5500"
  })
  res.write("beijing sun 18~65");
  res.end();
}).listen(3000)
//客户端: 打开浏览器
//地址栏: http://同桌ip:3000 回车
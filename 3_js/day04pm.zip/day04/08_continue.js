//打印1~10，不包括5
/*
for(var i=1;i<=10;i++){
  //当i为5的时候，跳过后边的循环体，执行增量
  if(i==5){
    continue;
	//break;
  }
  console.log(i);
}

//练习：计算1~100之间所有偶数的和，遇到奇数跳过
for(var i=1,sum=0;i<=100;i++){
  //i代表所有的整数
  //判断i是否为奇数，如果是就跳过
  if(i%2==1){
    continue;
  }
  //i剩余的都是偶数
  sum+=i;
}
console.log(sum);
*/
//打印1~100之间所有整除，不包含能被3整除或能被4整除的数字
for(var i=1;i<=100;i++){
  //如果i能被3整除或者能被4整除，跳过
  if(i%3==0 || i%4==0){
    continue;
  }
  console.log(i);
}







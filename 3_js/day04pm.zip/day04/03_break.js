//打印1~10之间所有的整数
/*
var i=1;
while(true){
  console.log(i);
  //当i为10的时候，结束循环
  //后边的循环体和循环条件都不执行
  if(i==10){
    break;
  }
  i++;
}
*/
//声明变量保存数字
var num=35;
//无限循环弹出提示框
while(true){
  //弹出提示框,并保存输入的值
  //如果文本框中不输入，默认就是空字符串''
  var str=prompt('input a number');
  //输入的值和之前保存就的值对比
  //如果输入的值大于保存的值
  if(str>num){
    alert('big');
  }else if(str<num){//如果输入的值小于保存的值
    alert('small');
  }else{//输入的值等于保存的值
    alert('right');
	break;//结束循环
  }
}
//var num=Number('');
//console.log(num);




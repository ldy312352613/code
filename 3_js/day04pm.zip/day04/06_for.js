//打印1~10之间所有的整数
/*
for(var i=1;i<=10;i++){
  console.log(i);
}
//练习：计算1~100之间所有整数的和
var sum=0;
for(var i=1;i<=100;i++){
  //i代表所有的整数
  sum+=i;
}
console.log(sum);

//练习：打印80 77 74 71 .... 50
for(var i=80;i>=50;i-=3){
  console.log(i);
}

//练习：计算1~20之间所有偶数的乘积
var ride=1;
for(var i=1;i<=20;i++){
  //i所有的整数
  //判断i是否为偶数
  if(i%2==0){
    ride*=i;
  }
}
console.log(ride);

//打印本世纪(2000~2100)所有的闰年
//能被4整除，并且不能被100整除，或者能被400整除
for(var i=2000;i<=2100;i++){
  //i所有的年份
  //判断i是否为闰年
  if(i%4==0 && i%100!=0 || i%400==0){
    console.log(i);
  }
}
*/

/*
*
**
***
****
*****

//打印5个*成一行  *****
//字符串的拼接
var str='';
for(var i=1;i<=5;i++){
  //console.log('*');
  //每次产生的*拼接到str中
  str+='*';
}
console.log(str);
*/
//1*5=5 2*5=10 3*5=15 4*5=20 5*5=25 
var str='';//'12345'
for(var i=1;i<=5;i++){
  str+=i+'*5='+(i*5)+' ';
}
console.log(str);




//*****
/*
for(var i=1,str='';i<=5;i++){
  //每次循环产生一个*,把它拼接到字符串str
  str+='*';
}
console.log(str);

//外层循环：控制循环5行 ———— j
for(var j=1;j<=5;j++){
  //内层循环：控制循环5列 ———— i
  for(var i=1,str='';i<=5;i++){
    //每次循环产生一个*,把它拼接到字符串str
    str+='*';
  }
  console.log(str);  
}
*/
//外层循环：控制循环的行数———j
for(var j=1;j<=9;j++){
  //内层循环：控制循环的列数———i
  for(var i=1,str='';i<=j;i++){
    //1   1
	//2   2
	//3   3
	str+='*';
  }
  //每行循环完，打印结果
  console.log(str);
}








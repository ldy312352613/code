//声明变量，保存密码
var pwd='123456';
//无限循环弹出提示框
/*
do{
  //弹出提示框，并获取输入的值
  var str=prompt('input password');
  //使用输入的值和保存密码比较
  if(str==pwd){
    alert('login success');
	//结束循环
	break;
  }
}while(true);
*/

do{
  var str=prompt('input password');
}while(str!=pwd);
//如果输入的不正确，继续执行循环体


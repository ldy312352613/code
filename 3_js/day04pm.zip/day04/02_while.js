//打印10次hello
//循环的范围1~10
//声明变量保存数字
/*
var i=1;
while(i<=10){ //循环条件
  //循环体
  //console.log('hello');
  console.log(i);
  //增量:每次加1
  i++;
}
//练习：打印11~50之间所有的整数
var i=11;
while(i<=50){
  console.log(i);
  i++;
}

//练习：打印100~1之间所有的整数
//初始值
//循环条件
//循环体
//增量
var i=100;
while(i>=1){
  console.log(i);
  i--;
}
//练习：打印20 22 24 26 28 30
var i=20;
while(i<=30){
  console.log(i);
  i+=2;
}
//练习：打印1~100之间所有的奇数，打印之前判断值是否为奇数。
//得到1~100所有整数，判断数字是否为奇数
var i=1;
while(i<=100){
  //i代表所有的整数
  //判断i是否为奇数
  if(i%2==1){
    console.log(i);
  }
  i++;
}

//练习：计算1~100之间所有整数的和
//得到1~100之间所有的整数
//提前声明变量，初始化值为0，把上边产生的整数加到变量中。
//初始化变量值为0，用于保存所有数字的和
var sum=0;
var i=1;
while(i<=100){
  //i就是所有的整数
  //把产生的所有整数加到sum中了
  sum+=i;
  //console.log(sum);
  i++;
}
console.log(sum);

//练习：计算1~100之间所有偶数的和
var i=1;
var sum=0;
while(i<=100){
  //i就是所有的整数
  //找i中所有的偶数
  if(i%2==0){
    //i就是所有的偶数
	sum+=i;
  }
  i++;
}
console.log(sum);
*/
//练习：计算1~15之间所有奇数的乘积。
//初始值1，每次 *=
var i=1;
var ride=1;
while(i<=15){
  //i就是所有的整数
  //判断i是否为奇数
  if(i%2==1){
    //把找到奇数i，乘以到ride中
	ride*=i;
  }
  i++;
}
console.log(ride);






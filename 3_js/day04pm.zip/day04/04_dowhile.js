//打印1~10之间所有的整数
/*
var i=100;
do{
  console.log(i);
  i++;
}while(i<=10);


//练习：打印100~1之间所有整数
var i=100;
do{
  console.log(i);
  i--;
}while(i>=1);

//练习：打印70 75 80 85 90 95 100
var i=70;
do{
  console.log(i);
  i+=5;
}while(i<=100);

//练习：计算1~100之间所有能被3整除的数字的和。
var i=1;
var sum=0;
do{
  //i就是1~100之间所有的整数
  //所有能被3整除的数字
  if(i%3==0){
    sum+=i;
  }
  i++;
}while(i<=100);
console.log(sum);
*/
//阶乘 5!=5*4*3*2*1
//练习：计算10的阶乘
var i=10;
var ride=1;
do{
  ride*=i;
  i--;
}while(i>=1);
console.log(ride);


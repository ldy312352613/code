var score=52;//8.2 -> 8
//成绩除以10，取整
//90以下  优秀
score=parseInt(score/10);
switch(score){
  case 10:
  case 9:
	console.log('优秀');
    break;
  case 8:
	console.log('良好');
    break;
  case 7:
	console.log('中等');
    break;
  case 6:
	console.log('及格');
    break;
  default:
	console.log('不及格');
}



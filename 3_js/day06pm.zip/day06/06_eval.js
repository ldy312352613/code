var str=prompt('input expression');
console.log(str);
console.log( eval(str) );
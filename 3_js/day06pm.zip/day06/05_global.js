/*
var url='http://www.codeboy.com/search?keyword=电脑';
//对一个URL中的中文进行编码
var str=encodeURI(url);
console.log(str);
//对一个URL进行解码
var str2=decodeURI(str);
console.log(str2);

//判断一个值是否为NaN
console.log(1+true);
console.log( isNaN(1+true) );
*/

//console.log(2/3);
//检测一个值是否为有限值
//Infinity
//console.log( isFinite(2/3) );

//执行字符串中的表达式
console.log( eval('parseInt(3.5)') );




//使用内置构造函数创建对象
var car=new Object();
car.id=120;
car.brand='BMW';
car['color']='black';
//console.log(car);
//练习：使用内置构造函数创建用户对象，包含编号，用户名，密码，邮箱，手机。

var user=new Object();//{}
user.uid=1;
user['uname']='dingding';
user['upwd']='123456';
user.email='ding@126.com';
user.phone='18112345678';
console.log(user);







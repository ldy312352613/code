//弹出3次警示框后结束
var i=0;
function fn(){
  i++;
  alert('long ago');
  //当i为3的时候，结束
  if(i==3){
	//结束函数，不是为了返回某个结果
    return;
  }
  //在函数内部调用自身————递归
  fn();
}
fn();
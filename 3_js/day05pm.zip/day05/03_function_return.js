//计算任意三个数字相加的和，并把结果返回
function add(a,b,c){
  return a+b+c;
  //return后的代码不执行
  //console.log('hello');
}
//把函数的返回结果保存到变量中
var num1=add(3,7,12);
//console.log(num1);

//练习：创建函数getMax，返回任意两个数字中的最大值
function getMax(a,b){
  /*
  if(a>b){
    return a;
  }else{
    return b;
  }*/
  return a>b ? a : b;
}
var n1=getMax(131,56);
//console.log(n1);
//练习: 创建函数getMax2，返回任意三个数字的最大值
function getMax2(a,b,c){
  //比较前两个，获取最大，并保存到变量
  var max= a>b ? a : b;
  //max和c比较，把最大值返回
  return max>c ? max : c;
}
var big=getMax2(3,7,15);
//console.log(big);

//练习：创建函数getStatus，传递状态码，返回对应的中文
function getStatus(code){
  //code就是传递的状态码
  switch(code){
    case 1:
	  return '等待付款';
	  //break;
	case 2:
	  return '等待发货';
	case 3:
	  return '运输中';
	case 4:
	  return '已签收';
	case 5:
	  return '已取消';
	default:
	  return '无法追踪';
  }
}
var s=getStatus(4);
//console.log(s);
//练习：创建函数getDays，传递任意一个年份，返回对应的天数
function getDays(year){
  if(year%4==0 && year%100!=0 || year%400==0){
    return 366;
  }
  return 365;
}
var days=getDays(2020);
//console.log(days);

//判断是否闰年，是返回true，不是返回false
function isRun(year){
  if(year%4==0 && year%100!=0 || year%400==0){
    return true;
  }
  return false;
}
//var res=isRun(2020);
//console.log(res);
//根据年份，返回天数
function getDays2(year){
  //判断年份year是否为闰年
  //如果是->true  不是->false
  if( isRun(year) ){
    return 366;
  }
  return 365;
}
var d=getDays2(2024);
//console.log(d);

//5! = 5*4*3*2*1
//1~100 所有整数的和
//计算1~任意数字之间所有整数阶乘的和
//传递一个参数
//步骤1：创建函数getJC，传递1个参数，计算任意数字的阶乘。1~n所有整数乘积
function getJC(n){
  for(var i=1,ride=1;i<=n;i++){
    ride*=i;
  }
  return ride;
}
var n1=getJC(10);
//步骤2：创建函数getSum，传递1个参数，计算1~任意数字之间所有整数的和 1~n的和
function getSum(n){
  for(var i=1,sum=0;i<=n;i++){
	//i代表中间所有的整数
	//获取数字的阶乘getJC(i)
    //sum+=i; //把所有的数字加到sum
	sum+=getJC(i);//把所有数字的阶乘加到sum
  }
  return sum;
}
var n2=getSum(20);
console.log(n2);










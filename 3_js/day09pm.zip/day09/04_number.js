var num1=new Number(true);//1
var num2=Number('1a');
//console.log(num2);
//console.log(num1,typeof num1);
//console.log(num1+3);
/*
console.log( Number.MAX_VALUE );
console.log( Number.MIN_VALUE );
*/
var num3=2*5*3.14;
console.log(num3.toFixed(1));
var num=0.1+0.2;
console.log(num.toFixed(1));
//数字转字符串
var num4=27;
console.log( num4.toString(16) );






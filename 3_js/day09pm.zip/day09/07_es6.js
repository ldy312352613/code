/*
function fn(){
  var a=1;
}

//块级作用域
{
  let a=2;
  let fn=function(){}
}
console.log(a);


for(let i=1;i<=10;i++){
  //1~10
  console.log(i);
}
//console.log(i);

if(3>2){
  let num=10;
}else{
  let num=20;
}
//console.log(num);

//2.箭头函数
var arr=[23,6,78,9,45];
//从小到大的排序
//console.log( arr.sort(function(a,b){
//  return a-b;
//}) );
//console.log( arr.sort((a,b)=>{
//  return a-b;
//}) );
console.log( arr.sort((a,b)=>b-a) );
*/

// 练习：创建函数add，传递两个参数，每个参数都是回调函数，在回调函数中返回一个数字；在函数add中计算两个数字相加的和
function add(a,b){
  console.log(a()+b())
}
add(()=>7,()=>8);










//5种转为false
//0  NaN  ''  undefined  null
var b1=new Boolean(NaN);
var b2=Boolean({});
//console.log(b1,typeof b1);
//console.log(b2);
console.log( !!undefined );
//转为字符串
console.log( b2.toString() );







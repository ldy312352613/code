var r=5;
const PI=3.14;
//面积和周长
var area=PI*r*r;
var len=2*PI*r;
console.log(area,len);
console.log(0.1+0.2);
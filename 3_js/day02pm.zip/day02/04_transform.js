//将任意的数据强制转为数值型
var num1=Number('a');
var num2=Number(undefined);
var num3=Number(null);
var num4=Number(true);
var num5=Number('1a');
//console.log(num5,typeof num5);
//强制转为整型
var num6=parseInt('3.5');//3
var num7=parseInt('1a');//1
var num8=parseInt('a1');//NaN
var num9=parseInt(undefined);//NaN
//练习：把布尔型的值和null转为整型
var num10=parseInt(true);
var num11=parseInt(null);
var num12=parseInt(3.5);

var num13=parseFloat('1.5a');

//console.log(num13,typeof num13);

//转为字符串类型
var num=10;
var str=num.toString();
var bool=true;
var str2=bool.toString();
console.log(str2,typeof str2);



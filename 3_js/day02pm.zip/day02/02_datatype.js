//数值型：整型和浮点型
//十进制
var num1=12;
//八进制
var num2=013;//11
//十六进制
var num3=0XF;
var num4=3.14;
//3140000  
var num5=3.14E6;
//0.00000314 
var num6=3.14E-6;

//console.log(num6);
//检测数据的类型
//console.log(typeof num6)

//字符串型
var str1='hello';
var str2='2';
//console.log(typeof str2);
//查看一个字符的Unicode码
//console.log( '字'.charCodeAt() );
//查看自己姓名的Unicode码

//布尔型
var isLogin=false;
var isIndex=true;
//console.log(isLogin,typeof isIndex);

//未定义型
var age;
console.log(age,typeof age);

//空
var person=null;





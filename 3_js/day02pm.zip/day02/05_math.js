//取余
/*
console.log(3%2);//1
console.log(2%3);//2
console.log(-2%3);//-2
//一个值是否为奇数
console.log(27%2);

//自增和自减
var num=1;
//先找到num空间，然后让里边的值加1
//num++;
//++num;
//console.log(num);//2
//先打印num当前的值，然后再去执行num加1,加1后num的值变成了2.
//console.log(num++);//1
//console.log(num);
//先执行num的值加1，num的值是2，然后再打印num
console.log(++num);//2
console.log(num);
*/

// 先取出num的值3；然后执行自减，num的值变成了称2。
//先执行自减，num的值变成了1，然后再取出num的值，也就是1.
//var num=3;
//console.log(num-- + --num);
      
var a='1';
//自增隐式将数据转为数值型
a++;
console.log(a,typeof a);










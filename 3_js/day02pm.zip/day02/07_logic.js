//满足老人或者儿童，满足其一
var age=25;
//console.log( age>=65 || age<=12 );
//练习：如果登录使用用户名root，或者使用手机号码18112345678，满足任意一种方式都是true，否则false。
var uname='root';
//比较uname的值是否为root，或者uname的值是否为18112345678
//console.log(uname=='root' || uname=='18112345678');

//80~90以下
var score=82;
//console.log(score>=80 && score<90);
//练习:声明变量保存用户名和密码，如果用户名是root，并且密码是123456，打印true，否则打印false
var uname='abc',upwd='123456';
//console.log(uname=='root' && upwd=='123456');

//console.log( !(3>1) );

/*
var num=3;
num>5  &&  console.log(a);
num<1  ||  console.log(a);
*/

//练习：声明变量保存一个人的年龄，如果满18岁，打印'成年人'
var age=11;
age>=18 && console.log('成年人');

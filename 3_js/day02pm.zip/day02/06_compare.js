//console.log(2<1);
//比较值
/*
console.log(2=='2');
//比较值和类型
console.log(2==='2');
console.log(1==true);
console.log(1===true);

//console.log(3>'10');
//比较的是Unicode码
console.log('ab'>'ac');
console.log('是'.charCodeAt());
*/


//'10a'转成数值型，调用Number，返回NaN
console.log(3>'10a');
console.log(3<'10a');
console.log(3=='10a');
console.log(NaN==NaN);
console.log(3!='10a');


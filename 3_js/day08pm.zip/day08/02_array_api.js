var arr=['html','css','js'];
//作用
//参数
//返回值
//在数组末尾添加元素
//console.log( arr.push('nodejs') );
//删除数组末尾的元素
//console.log( arr.pop() );
//在数组开头添加元素
//console.log( arr.unshift('ajax') );
//在数组开头删除元素
console.log( arr.shift() );
console.log(arr);

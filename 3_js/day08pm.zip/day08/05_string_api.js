//var str='javascript';
//计算字符串的长度
//console.log( str.length );
//获取下标对应的字符
//console.log( str[2] );
//console.log( str.charAt(4) );
//练习：遍历字符串，打印出每一个字符（循环下标）
/*
for(var i=0;i<str.length;i++){
  console.log(str[i],str.charAt(i));
}

console.log( 'a'.charCodeAt() );

var str='javascript';
//查找字符对应的下标
console.log( str.indexOf('a') );
console.log( str.lastIndexOf('a') );

//练习：声明变量保存字符串，检测该字符串中是否含有@，如果有打印“合法的邮箱“，否则打印“不合法邮箱”。
var email='hello#tedu.cn';
if( email.indexOf('@')>=0 ){
  console.log('合法的邮箱');
}else{
  console.log('不合法的邮箱');
}

var str='JavaScript';
//将英文字母转大写
console.log( str.toUpperCase() );
console.log( str.toLowerCase() );

var str='javascript';
//截取字符串
console.log( str.slice(4) );
console.log( str.slice(4,7) );
console.log( str.slice(-3,-1) );

//练习：声明变量保存邮箱，分别截取出邮箱的用户名和域名 
var email='tom123456@163.com';
//查找@的下标
var index=email.indexOf('@');
//截取用户名：0~@的下标
console.log( email.slice(0,index) );
//截取域名：@的下标下一位~最后
console.log( email.slice(index+1) );

var str='javascript';
//截取指定的长度
console.log( str.substr(4,3) );
console.log( str.substr(-3,2) );

//练习：声明变量保存身份证号，截取出年月日和性别；打印1998年06月20日 性别女
var id='110236199806202589';
//截取年月日，性别
var year=id.substr(6,4);
var month=id.substr(10,2);
var date=id.substr(12,2);
var sex=id.substr(-2,1)%2==0 ? '女' : '男';
console.log(year+'年'+month+'月'+date+'日 性别'+sex);

var str='javascript';
//截取字符串
console.log( str.substring(4) );
console.log( str.substring(4,7) );
console.log( str.substring(7,4) );

//练习：将一个英文单词的首字母转大写，其余的字母转小写
var str='heLLo';
//截取首字母
var begin=str.substring(0,1).toUpperCase();
//截取第2个字符到最后
var last=str.substring(1).toLowerCase();
console.log(begin+last);

//数组转字符串
var arr=['html','css','js'];
var str=arr.join('-');//html-css-js
//console.log(str);
//将字符串分隔成数组
var arr2=str.split('-');
console.log(arr2);
*/
//练习：使用split分隔邮箱，获取用户名和域名
var email='tom123@163.com';
//按照@分隔字符串为数组
var arr=email.split('@');
console.log(arr[0],arr[1]);






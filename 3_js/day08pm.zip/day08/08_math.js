//圆周率
//console.log( Math.PI );
//绝对值
//console.log( Math.abs(18-20) );//absolute
//取整
//console.log( parseInt(3.9) );
//向下取整
//console.log( Math.floor(3.9) );
//向上取整
//console.log( Math.ceil(3.9) );
//四舍五入取整
//console.log( Math.round(3.49) );
//获取最大值
//console.log( Math.max(23,6,78,9,45) );
//获取最小值
//console.log( Math.min(23,6,78,9,45) );
//获取x的y次幂
//console.log( Math.pow(5,2) );
//获取随机  0~1  >=0  <1
//console.log( Math.random() );
//练习：随机产生0~9之间的一个整数。
var num=Math.floor( Math.random()*10 );  //0~9.99
console.log(num);




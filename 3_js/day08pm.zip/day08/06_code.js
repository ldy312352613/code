//声明变量
var code='aSDf';
//无限循环弹出提示框
while(true){
  //获取输入的内容
  var str=prompt('input checkcode');
  //比较输入的内容和验证码是否一致
  if( str.toUpperCase()==code.toUpperCase() ){
	//结束循环
    break;
  }

}
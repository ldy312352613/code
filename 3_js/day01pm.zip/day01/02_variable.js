//声明变量
var x=1;
var y=2;
// 练习：声明多个变量，分别保存一个员工的编号、姓名、性别、生日、工资、部门编号，并打印出来。
var eid=1; 
var ename='凯特';
var sex=0;
var birthday='1994-10-20';
var salary=8000;
var deptId=20;
//console.log(eid,ename,sex,birthday,salary,deptId);
var _$a1=10;
//console.log(_$a1);

//声明变量未赋值
//弱类型语言，声明变量的时候不需要指定数据类型，后期可以存储任意的类型。
var num;
//console.log(num);//undefined 未定义
//把数据存放到num中
num=3;
//console.log(num);
num=5;
//console.log(num);
num='abc';
//console.log(num);

//一次性声明多个变量
var a=1,b=2,c;
//console.log(a,b,c);

var chinese=96,math=98,total;
total=chinese+math;
//console.log(total);

//声明常量
const PI=3.14;
//PI=3.1415;
console.log(PI);

/*
  多行注释
*/
console.log('hello world');
//console.log('javascript');
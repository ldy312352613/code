var age=17;
//是否满18岁 
//age>=18 ? console.log('成年人') : console.log('未成年人');
var res=age>=18 ? '成年人' : '未成年人';
//console.log(res);
//练习：声明两个变量保存数字；比较两个数字的大小，打印最大值。
var a=30,b=20;
var res=a>b ? a : b;
//console.log(res);
//练习：声明两个变量分别保存用户名和密码，如果用户名是root，并且密码是123456，打印'登录成功',否则打印'登录失败'
var uname='abc';
var upwd='123456';

var res=(uname=='root' && upwd=='123456') ? '登录成功' : '登录失败';
console.log(res);







//根据订单的状态码打印对应中文
var status=7;
switch(status){
  case 1: //如果status的值是1
    console.log('等待付款');
	break;
  case 2:
	console.log('等待发货');
    break;
  case 3:
	console.log('运输中');
    break;
  case 4:
	console.log('已签收');
    break;
  case 5:
	console.log('已取消');
    break;
  default:
	console.log('错误的状态码');
}
//练习：获取星期的值 0~6，星期日~星期六
//根据星期的状态码打印对应中文形式
//声明变量保存星期代码
var day=2;
switch(day){
  case 0:
	console.log('星期日');
    break;
  case 1:
	console.log('星期一');
    break;
  case 2:
	console.log('星期二');
    break;
  case 3:
	console.log('星期三');
    break;
  default:
	console.log('错误的星期代码');
}



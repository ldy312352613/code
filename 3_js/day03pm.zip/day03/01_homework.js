var year=2020;
//如果是闰年，打印'闰年'
//如果前边是true，执行后边
//  &&
//先执行&&   再执行||
//(year%4==0 && year%100!=0 || year%400==0) && console.log('闰年');
(year%400==0 || year%4==0 && year%100!=0) && console.log('闰年');

(year%400==0 || year%4==0 && year%100!=0) || console.log('平年');


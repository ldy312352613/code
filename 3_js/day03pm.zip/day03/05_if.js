//满30减12
//如果订单金额满30，在原来的基础之上减12
var total=28;
if(total>=30){
  total-=12;
}
//console.log(total);
//练习：声明变量保存年龄，如果满18，打印成年人。
/*
var age=21;
if(age>=18){
  console.log('成年人'); 
}

//false: 0 NaN '' undefined null
if(!''){
  console.log(3);
}
*/
//练习：声明变量保存个人签名，如果签名内容为空，给变量赋值'这家伙很懒，什么也没留下'；最后打印变量。
var str='天大地大';
//判断签名是否为空字符串
if(str==''){
  str='这家伙很懒，什么也没留下';
}
/*
if(!str){
  str='这家伙很懒，什么也没留下';
}
*/
console.log(str);



//如果余额足够支付订单金额，支付成功，否则支付失败
var money=58;//余额
var total=70;//订单金额
//money>=total ? console.log('支付成功') : console.log('支付失败');
/*
if(money>=total){
  console.log('支付成功');
}else{
  console.log('支付失败');
  console.log('请充值');
}
*/
//练习：声明变量保存性别的值(1/0),如果是1，打印‘男’；否则打印‘女’
var sex=1;
//0-false  1-true
if(sex)
  console.log('男');
else
  console.log('女');








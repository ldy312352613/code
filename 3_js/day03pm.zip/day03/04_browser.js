//弹出警示框
//alert('web');
//alert('tedu.cn');
//弹出提示框(输入框)
//把输入的值存到变量中
//var str=prompt('input your name');
//console.log(str,typeof str);
//练习：弹出两次提示框，分别输入两个数字，计算两个值相加；把相加的结果以警示框形式弹出。
var num1=prompt('input first number');
var num2=prompt('input second number');
//把num1和num2转为数值型
num1=Number(num1);
num2=Number(num2);
//弹出相加的结果
alert(num1+num2);



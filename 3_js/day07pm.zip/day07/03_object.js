var book={
  id:1002,
  title:'javascript高级程序设计',
  price:79
}
//把book变量中存储的数据赋给book2变量
//把book存储的地址赋给了book2
//现在book和book2指向同一个对象
var book2=book;
//使用不同的变量去修改同一个对象
//修改book中属性
book.price=86;
//console.log(book2);
//修改book2的属性
book2.title='JavaScript权威指南';
//console.log(book);

//原始类型存储
var a=1;
var c=a;
c=3;
//console.log(a);


//fn提升到最前边
//var fn;
//function fn(){}//把一个函数赋给fn
console.log(fn);
var fn=1;//再次覆盖了fn中的值
function fn(){
}
//console.log(fn);



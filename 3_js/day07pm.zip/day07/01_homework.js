/*
var fn=function(){}
function fun(){}
console.log(fn);
console.log(fun);
*/

var circle=new Object();
circle.r=5;
circle.PI=3.14;
circle.getArea=function(){
  //计算圆的面积
  return this.PI*this.r*this.r;
}
circle.getLength=function(){
  //计算周长
  return 2*this.PI*this.r;
}
console.log( circle.getArea() );
console.log( circle.getLength() );







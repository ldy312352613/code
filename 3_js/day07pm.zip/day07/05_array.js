//使用字符串作为下标————关联数组
/*
var person=[];
person['name']='tom';
person['age']=18;
person['sex']='男';
person['phone']='18112345678';
//console.log(person);
for(var key in person){
  //key要遍历的元素的下标
  //person[key] 下标对应的元素
  console.log(key,person[key]);
}
*/
/*
var sum=0;
var score=[81,93,95,78,66,84,72];
//使用for循环获取下标0~4，使用下标获取元素
for(var i=0;i<score.length;i++){
  //i 代表下标
  //score[i] 下标对应的元素
  //console.log(i,score[i]);
  sum+=score[i];
}
console.log(sum);


for(var key in score){
  //console.log(key,score[key]);
  sum+=score[key]
}
console.log(sum);
*/

//
var list=[
  {lid:1,title:'apple',price:6888},
  {lid:2,title:'dell',price:4999},
  {lid:3,title:'小米',price:3999}
];








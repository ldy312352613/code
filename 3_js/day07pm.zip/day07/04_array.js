//创建数组，保存若干个员工的姓名
var emps=['tom','jerry','kate'];
//console.log(emps);
var laptop=['小米Air','Apple Pro','联想E450','戴尔灵越7000'];
var city=['巴黎','伦敦','罗马','马德里'];
//console.log(laptop,city);
//通过下标来获取元素
//console.log( city[4] );
city[4]='布鲁塞尔';
city[2]='米兰';

//console.log(city);

var car=new Array('奔驰','宝马','奥迪');
var car2=new Array(3);
car2[0]='凯迪拉克';
car2[1]='沃尔沃';
car2[2]='捷豹';
car2[3]='路虎';
//console.log(car2);
//练习：创建数组，保存若干个课程名称；
var course=new Array('JS基础','NodeJS','HTML','CSS');
//console.log(course);
//练习：创建数组，初始化长度为5，添加篮球场上的五个位置
var ball=new Array(5);
ball[0]='大前锋';
ball[1]='小前锋';
ball[2]='中锋';
ball[3]='控球后卫';
ball[4]='得分后卫';
ball[ball.length]='普通后卫';
ball[ball.length]='进攻后卫';
//console.log(ball);
//获取数组的长度
//console.log(ball.length);
//练习：创建一个空数组，使用数组长度添加若干个国家名称。
var country=[];
country[country.length]='china';
country[country.length]='America';
country[country.length]='japan';

console.log(country);
console.log(typeof country);
var person={};
console.log(typeof person);










/*
var names=['tom','king','david','lucy','tom'];
//遍历数组 
for(var i=0;i<names.length;i++){
  if(names[i]=='tom'){
    names[i]='汤姆';
  }
}
console.log(names);

//练习：创建数组，包含多个姓名，查询tom出现的次数
var names=['kate','king','tom','scott','tom'];
//遍历数组，获取每个元素
for(var i=0,count=0;i<names.length;i++){
  //如果每个元素为tom，则次数加1
  if(names[i]=='tom'){
    count++;
  }
}
console.log(count);

//练习：创建数组，包含多个数字，获取这组数字的最大值
var score=[23,85,74,46,95,100];
//声明变量，保存最大值,
var max=score[0];
//遍历数组，获取每个元素
//遍历的时候，只需要从第2个开始
for(var i=1;i<score.length;i++){
  //用max和数组每个元素比较
  //如果小于任意一个元素，则把该元素放入到max中
  if(max<score[i]){
    max=score[i];
  }
}
console.log(max);
*/
//练习：创建函数getAvg，传递一个参数(一组工资)，返回工资的平均值
function getAvg(salary){
  //salary就是一个数组
  //遍历salary，获取数组元素的和
  for(var i=0,sum=0;i<salary.length;i++){
    sum+=salary[i];
  }
  //平均=总和/元素个数
  return sum/salary.length;
}
console.log( getAvg([8000,14000,4000,9000]) );








/***Webpack主配置文件***/
module.exports = {
  mode: 'production',  //产品模式，输出文件会进行压缩
  //mode: 'development', //开发模式，输出文件不进行压缩
  
  //1.入口：从哪个文件开始打包
  entry: './src/js/index.js',
  //2.出口：打包后的结果输出到哪个文件
  output: {
    path: __dirname+'/dist',
    filename: 'app.js',
  },
  //3.加载器：默认情况下Webpack只能打包JS！如果想打包其它格式的文件必须使用对应的加载器(loader)——查手册即可
  module: {     //非JS模块的加载规则
    rules: [ 
      {  //检测如果模块以.css结尾的话，就用指定的两个加载器打包
        test: /\.css$/,
        use:['style-loader', 'css-loader']
      }
    ]
  }
  //4.插件，扩展Webpack的功能，如实现自动实时刷新等
}
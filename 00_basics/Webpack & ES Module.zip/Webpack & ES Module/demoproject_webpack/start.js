const express = require('express');

var app = express();
app.listen(8090, ()=>{
    console.log('Server Listening on 8090...');
});

app.use(express.static('./'));
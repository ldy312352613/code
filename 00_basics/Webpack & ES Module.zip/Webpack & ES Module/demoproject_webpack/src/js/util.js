//导出当前模块中的函数供其它模块使用
//ES6模块导出语法
export  default  function getCompanyName(){
	return 'TEDU.CN';
}
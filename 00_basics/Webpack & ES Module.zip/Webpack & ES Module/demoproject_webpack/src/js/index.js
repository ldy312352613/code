//ES6模块导入语法
//当前JS文件依赖于另一个JS文件
import getCompanyName from './util';

//当前JS文件依赖于另外的CSS文件
import '../css/base.css';
import '../css/index.css';
//require('../css/base.css');

function createDiv() {
  var div = document.createElement('div');
  div.classList.add('hello');
  div.innerHTML = '版权所有：'+getCompanyName();
  return div;
}
document.body.appendChild(createDiv());



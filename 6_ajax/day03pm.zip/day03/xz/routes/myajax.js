//引入连接池模块
const express=require('express');
//创建路由器对象
const pool=require('../pool.js');
//添加路由
var router=express.Router();
//1.测试服务器接收ajax请求的接口
router.get("/ajaxDemo",(req,res)=>{
	res.send("第一个ajax程序");
});
//2.测试带参数的get请求
router.get("/ajaxDemo1",(req,res)=>{
	//1.接收参数
	var $uname=req.query.uname;
	var $upwd=req.query.upwd;
	//2.验证接收参数成功
	if(!$uname){
		res.send("用户名未接收到");
		return;
	}
	if(!$upwd){
		res.send("密码未接收到");
		return;
	}
	res.send("用户名为："+$uname+",密码为:"+$upwd);
});
//导出路由器对象
module.exports=router;
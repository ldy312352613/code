#设置客户端连接服务器编码
SET NAMES UTF8;
#丢弃数据库，如果存在
DROP DATABASE IF EXISTS xz;
#创建数据库xz,设置存储的编码
CREATE DATABASE xz CHARSET=UTF8;
#进入该数据库
USE xz;
#创建保存笔记本家族的表
CREATE TABLE laptop_family(
  fid SMALLINT PRIMARY KEY,
  fname VARCHAR(8) UNIQUE,
  laptopCount INT DEFAULT 1
);
#插入数据
INSERT INTO laptop_family VALUES(10,'联想',2);
INSERT INTO laptop_family VALUES(20,'戴尔',2);
INSERT INTO laptop_family VALUES(30,'小米',3);
INSERT INTO laptop_family VALUES(40,NULL,4);
INSERT INTO laptop_family VALUES(50,'华硕',DEFAULT);
INSERT INTO laptop_family(fid,fname) VALUES(60,'神州');

#创建保存笔记本数据的表
CREATE TABLE laptop(
  lid INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(64) UNIQUE,
  price DECIMAL(7,2) NOT NULL DEFAULT 6999,   #99999.99
  spec VARCHAR(32) UNIQUE,
  detail VARCHAR(3000),
  shelfTime DATE NOT NULL,
  isOnsale BOOL NOT NULL,
  familyId SMALLINT,
  FOREIGN KEY(familyId) REFERENCES laptop_family(fid)
);
#插入数据
INSERT INTO laptop VALUES(1,'小米Air',4999,'13.3银色','详情一','2018-5-1',1,30);
INSERT INTO laptop VALUES(2,'联想E480C',3499,'游戏本','详情二','2018-8-1',1,10);
INSERT INTO laptop VALUES(3,'戴尔燃7000',5499,'办公本','详情三','2017-8-1',0,20);
INSERT INTO laptop VALUES(4,'联想小新700',5199,'电竞版','详情四','2016-12-1',0,NULL);
INSERT INTO laptop VALUES(5,'戴尔燃7001',4699,'游戏版','详情五','2018-4-5',1,20);
INSERT INTO laptop VALUES(6,NULL,8199,'开发版','详情六','2019-4-1',1,30);
INSERT INTO laptop VALUES(7,NULL,3188,'测试版','详情七','2018-11-1',1,10);
INSERT INTO laptop VALUES(8,'神州3000',DEFAULT,'游戏本1','详情八','2019-1-1',1,60);
INSERT INTO laptop(lid,shelfTime,isOnsale) VALUES(19,'2019-3-1',1);
INSERT INTO laptop(lid,shelfTime,isOnsale) VALUES(NULL,'2019-3-1',1);
INSERT INTO laptop(lid,shelfTime,isOnsale) VALUES(NULL,'2019-3-1',1);
INSERT INTO laptop(lid,shelfTime,isOnsale) VALUES(16,'2019-3-1',1);





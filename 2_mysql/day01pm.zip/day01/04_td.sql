#先丢弃数据库td，如果存在
DROP DATABASE IF EXISTS td;
#创建数据库td
CREATE DATABASE td;
#进入该数据库
USE td;
#创建保存员工数据的表emp
CREATE TABLE emp(
  eid INT,
  ename VARCHAR(8),
  addr VARCHAR(16),
  phone VARCHAR(11)
);







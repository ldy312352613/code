#丢弃数据库，如果存在
DROP DATABASE IF EXISTS dang;
#创建数据库
CREATE DATABASE dang;
#进入该数据库
USE dang;
#创建数据表book
CREATE TABLE book(
  bid INT,
  title VARCHAR(8),
  price INT
);
#插入数据
INSERT INTO book VALUES('1','one','20');
INSERT INTO book VALUES('2','two','18');
#修改数据
UPDATE book SET price='28' WHERE bid='1';
#删除数据
DELETE FROM book WHERE bid='2';
#查询数据
SELECT * FROM book;









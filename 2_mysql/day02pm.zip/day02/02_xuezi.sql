#设置客户端连接服务器的编码
SET NAMES UTF8;
#先丢弃数据库xuezi,如果存在
DROP DATABASE IF EXISTS xuezi;
#创建数据库xuezi,设置存储的编码
CREATE DATABASE xuezi CHARSET=UTF8;
#进入该数据库
USE xuezi;
#创建保存笔记本数据的表
CREATE TABLE laptop(
  lid INT,
  title VARCHAR(64),
  price DECIMAL(8,2),  #999999.99
  stockCount SMALLINT,
  shelfTime DATE,
  isIndex BOOL
);
#插入数据  
INSERT INTO laptop VALUES
(1,'联想E450',3699,700,'2018-10-1',TRUE),
('2','戴尔灵越310','4288','100','2018-11-1',FALSE),
('3','戴尔灵越330','5288','300','2018-12-1',1),
('4','Apple Air','6288','400','2018-3-1',0);









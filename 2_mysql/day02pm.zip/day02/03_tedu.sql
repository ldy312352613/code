#设置客户端连接服务器端编码
SET NAMES UTF8;
#丢弃数据库tedu,如果存在
DROP DATABASE IF EXISTS tedu;
#创建数据库tedu,设置存储的编码
CREATE DATABASE tedu CHARSET=UTF8;
#进入该数据库
USE tedu;
#创建保存部门数据的表、
CREATE TABLE dept(
  did SMALLINT,
  dname VARCHAR(8),
  empCount SMALLINT
);
INSERT INTO dept VALUES
(10,'研发部',3),
(20,'市场部',2),
(30,'运营部',2);
#创建保存员工数据的表 
CREATE TABLE emp(
  eid INT PRIMARY KEY,
  dname VARCHAR(6),
  sex BOOL,
  birthday DATE,
  salary DECIMAL(8,2), #999999.99
  deptId SMALLINT
);
INSERT INTO emp VALUES
(1,'汤姆',1,'1994-5-20',8000,10),
(20,'杰瑞',0,'1995-10-2',9000,20),
(3,'凯特',0,'1996-8-5',12000,30),
(42,'戴维',1,'1997-8-20',10000,10);
INSERT INTO emp VALUES(5,'托马斯',1,'1998-2-2',6500,20);
INSERT INTO emp VALUES(9,'金',1,'1993-6-2',NULL,30);




